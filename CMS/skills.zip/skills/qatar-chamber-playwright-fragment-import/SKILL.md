---
name: qatar-chamber-playwright-fragment-import
description: Import (or re-import) the qc-website-sections fragment collection
  zip (and the qc-master master page zip) into the Qatar Chamber Liferay site.
  ALWAYS PREFER the fixed standalone automation scripts under automation/
  (import-fragments.js / import-master.js); drive the admin UI live via the
  Playwright MCP tools only as a fallback when those scripts cannot run. Use
  when a demo run's implementation phase is blocked on "Deploy step (T29)
  blocked" / fragment.fragmententry-not-registered, or whenever fragment code
  needs to be pushed into a running Liferay instance without a build/deploy
  pipeline.
---

# Qatar Chamber Fragment Import

Two ways to push `qc-website-sections.zip` (and `qc-master.zip`) into the
running Liferay instance when the JSONWS `fragment.fragmententry` /
`update-fragment-entry` route is not registered:

1. **Preferred — the fixed automation scripts** (`automation/scripts/*`). Fully
   working and verified end-to-end.
2. **Fallback — drive the admin UI live** with the `mcp__playwright__*` tools.

## Preferred: run the automation scripts

Always try this first. The scripts under `automation/` were rewritten and
verified (2026-07-11) and now handle everything the old prose steps did:
login, locale-proof navigation, the overwrite step, the modal commit, and
pressing Done.

```powershell
cd D:\Qatar-Chamber\Repository\qatar-chamber-be\automation
npm install                       # first time only
npx playwright install chromium   # first time only
Copy-Item .env.example .env        # first time only; defaults already target this instance
npm run import-fragments          # imports qc-website-sections.zip into "QC Website Sections"
npm run import-master             # imports qc-master.zip (masters / page templates)
```

Dry run (walks the whole flow, selects Overwrite, but skips the final commit —
no live changes):

```powershell
$env:DRY_RUN="true"; npm run import-fragments
```

What the scripts already do for you (do NOT re-implement inline):

- **Login** at `/c/portal/login`; correctly detects success even though the
  site runs in Arabic (an earlier bug reported every login as failed).
- **Navigate by portlet id**, not the Product Menu — locale-proof. Fragments:
  `com_liferay_fragment_web_portlet_FragmentPortlet`; masters / page templates:
  `com_liferay_layout_page_template_admin_web_portlet_LayoutPageTemplatesPortlet`
  (note the id is singular `..._page_template_admin_...` +
  `LayoutPageTemplatesPortlet`, NOT `...AdminPortlet`). Each goes straight to
  the import form via `mvcRenderCommandName=.../view_import`.
- **Find the collection by name** (`FRAGMENT_COLLECTION_NAME`, default "QC
  Website Sections") and derive its id from the sidebar link at runtime.
- **Two-step import wizard**: attach zip → Import (parses, commits nothing) →
  an "Import Options" modal → selects **Overwrite Existing Items**
  (`input[type=radio][value="overwrite"]` — the value is locale-stable; the
  label is "Overwrite Existing Items" / "كتابة فوق العناصر الموجودة") → clicks
  the modal's Import to commit.
- **Results + Done**: reads the "N items were imported." results page and
  presses **Done**, then exits.
- On failure, writes `automation/<name>-error.png`.

Key selectors (in `automation/scripts/lib/liferay-helpers.js`) if a Liferay
upgrade breaks them: file input `input[type=file]` (hidden — waited as
`attached`), primary submit `.btn-primary`, modal commit `.modal.show
.btn-primary`, overwrite radio `input[type=radio][value="overwrite"]`, Done
`.btn-primary` on the results page.

Only fall back to the MCP UI-driving steps below if the scripts genuinely can't
run (e.g. no node/npm, browser download blocked) or you need inline
screenshot/DOM verification in the current session.

## Fallback: drive the admin UI via Playwright MCP

Drives the Liferay admin UI directly with the `mcp__playwright__*` tools to
import `qc-website-sections.zip` (Design -> Fragments -> Options -> Import).

## Preconditions

- Liferay running at `http://localhost:8080` (check: `curl -s -o /dev/null -w
  "%{http_code}" http://localhost:8080/c/portal/login` -> `302`).
- `build-resources/fragments/qc-website-sections.zip` exists and is up to
  date (rebuild first if needed -- see `qatar-chamber-deploy-fragment` skill's
  "Build the deployable zips" section).
- Playwright MCP tools available (`mcp__playwright__browser_navigate`,
  `_snapshot`, `_click`, `_fill_form`, `_file_upload`, `_wait_for`,
  `_take_screenshot`).

## Steps

### 1. Log in

```
browser_navigate -> http://localhost:8080/c/portal/login
```
Redirects to `/sign-in?...`. Take a snapshot, then fill and submit:

```
browser_fill_form:
  Email Address (textbox) = test@liferay.com
  Password (textbox)      = test
browser_click -> Sign In button
```
Lands on `http://localhost:8080/home`.

### 2. Navigate to the site's Fragments page

Fastest: go straight to the Fragments portlet by id (this is what the
automation scripts do and it is locale-proof) —
`http://localhost:8080/group/qatar-chamber/~/control_panel/manage?p_p_id=com_liferay_fragment_web_portlet_FragmentPortlet&p_p_lifecycle=0&p_p_state=maximized`.
Note the id: `com_liferay_fragment_web_portlet_FragmentPortlet` works; the
`..._internal_portlet_FragmentEntryOrderPortlet` id 404s with "This portlet
could not be found." If you'd rather click through, drive the Product Menu
(section is "Design", localized — Arabic "تصميم"), noting the bare
`.../control_panel/manage` page is an empty "select a tool" shell until a
portlet id is supplied:

```
browser_navigate -> http://localhost:8080/group/qatar-chamber/~/control_panel/manage
browser_click -> "Design" menuitem (top nav menubar)   # opens submenu
browser_click -> "Fragments" menuitem                   # inside the Design submenu
```
Lands on `.../control_panel/manage/-/fragments/fragment_collections?p_p_auth=<token>`.
The `p_p_auth` token is session-specific -- always re-read it from the current
snapshot/URL, never hardcode a prior run's value.

### 3. Open Import for the QC Website Sections collection

The collection list shows fragment sets grouped by source ("Qatar Chamber" ->
"QC Website Sections"). Existing fragments are listed as definitions with
"N Usages" / "Approved" status -- if you see `QC Home Hero Banner` (or any
target fragment) already there, that's expected on a re-import, not a sign of
success by itself.

```
browser_click -> "Show Actions" button in the "QC Website Sections" heading
```
Opens a menu with `Edit`, `Export`, `Import`, `Delete`.

```
browser_click -> "Import" menuitem
```
Navigates to `.../fragment_collection/<collectionId>?..._mvcRenderCommandName=%2Ffragment%2Fview_import&p_p_auth=<token>`.

### 4. Upload the zip

```
browser_click -> "Select File" button   # opens a file chooser modal
browser_file_upload -> ["<absolute path>\\build-resources\\fragments\\qc-website-sections.zip"]
```
Page updates to "The file was loaded. Click the import button to import it."
and the `Import` button becomes enabled.

```
browser_click -> "Import" button
```

### 5. Resolve the conflict dialog

If any fragment in the zip already exists in the collection, an "Import
Options" dialog appears with three radios (default: **Do Not Import Existing
Items**):

- Do Not Import Existing Items
- **Overwrite Existing Items** <- select this for a normal re-deploy of
  updated fragment code
- Keep Both

```
browser_click -> "Overwrite Existing Items" radio
browser_click -> "Import" button (inside the dialog)
```

### 6. Verify

Wait ~2-3s, then snapshot. Success shows a collapsible result banner:
`"N items were imported."` listing every fragment name from the zip, with
**no warning text** (compare against the expected fragment list, e.g. `QC
Home Strategic Partners`, `QC Site Header`, `QC Home Hero Banner`, `QC Site
Footer`). Click **Done** to return to the collection view.

Then open the specific fragment's editor to confirm it renders:

```
browser_navigate -> http://localhost:8080/group/qatar-chamber/~/control_panel/manage/-/fragments/fragment_collection/<collectionId>/fragment_entry/<id>/edit?p_p_auth=<token>
browser_take_screenshot  # snapshot on this page is often too large (100k+ tokens) -- use a screenshot instead
```
Confirm the Code tab shows the expected HTML/CSS/JS with no import-warning
banner above it.

## Known non-blocking noise

The fragment editor page for this project loads the `qc-frontend` global-JS
client extension, which throws:
```
TypeError: Cannot read properties of null (reading 'appendChild')
  at http://localhost:8080/o/qc-frontend/qc-head-hooks.js:47:17
```
This is a pre-existing global-injection issue unrelated to fragment import
(see `qc-client-extension-global-injection-gotchas` memory) -- do not treat it
as an import failure.

## After import

- Record the outcome in the run's `state.json` (`implementation` phase /
  `t29Status` / add a `deployResolution` note) via the
  `state-management-skill` -- do not silently leave the prior
  `IMPLEMENTATION_FAILED` error looking unresolved.
- If the fragment isn't yet placed on a page, that's a separate step (page
  edit -> drag fragment from Fragments & Widgets panel) -- importing the
  collection does not place it anywhere automatically.
- No compensation-log entry applies to a fragment-collection import itself
  (the `compensationEntry.schema.json` `resourceType` enum has no `fragment`
  value, and unlike Object Definitions this is a UI-only, non-headless-API
  action) -- do not force one.

## Related skills

- `qatar-chamber-deploy-fragment` -- builds the zip, documents the manual UI
  steps in prose, and the equivalent standalone node/Playwright scripts under
  `automation/`.
- `state-management-skill` -- how to read/patch a demo run's `state.json`.
