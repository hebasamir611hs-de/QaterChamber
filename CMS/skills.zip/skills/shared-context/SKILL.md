---
name: shared-context
description: Canonical facts, paths, ERC scheme, locales, glossary, gate and
  plan-validation rules shared by every agent in the Qatar Chamber demo.
  Load this first, always.
---

# Shared Context

## Environment
- Liferay DXP (quarterly LTS line; pin exact version per environment),
  JDK 21, Tomcat on port 8080.
- Liferay base URL: http://localhost:8080
- Liferay MCP endpoint: http://localhost:8080/o/mcp (feature.flag.LPD-63311=true).
- Liferay admin: test@liferay.com (demo password "test"). NEVER print
  credentials in logs, comments, or reports.
- Database: MySQL 8.4 LTS, localhost:3306, schema qatarchamberdev, user
  qatarchamberdev, driver com.mysql.cj.jdbc.Driver, charset utf8mb4 /
  utf8mb4_unicode_ci. The JDBC password is defined in portal-ext.properties
  (demo). NEVER echo it.
- Company default timezone: Asia/Qatar. Agent timestamps: UTC ISO-8601.
- Azure DevOps org slug: ihorizons
- Azure DevOps project: 'Qatar Chamber Website Revamp'
- Work item type: 'Product Backlog Item' (Scrum). NEVER query 'User Story'.

## Canonical paths
- Liferay home: D:\Qatar-Chamber\Repository\qatar-chamber-be\bundles
- portal-ext.properties: {home}\portal-ext.properties
- portal-setup-wizard.properties: {home}\portal-setup-wizard.properties
- Connector jar: {home}\tomcat\webapps\ROOT\WEB-INF\shielded-container-lib\mysql-connector-j-8.4.0.jar
- Cache root: C:\temp\demo-ih-cache
- Active run pointer: {root}\current-run
- Per-run state: {root}\runs\{runId}\state.json
- Derived plan: {root}\runs\{runId}\structure.json
- Plan validation findings: {root}\runs\{runId}\plan-validation.json
- Artifacts: {root}\runs\{runId}\artifacts\
- Schemas: {root}\schemas\*.json
- Arabic glossary: {root}\glossary\ar_SA.json
- Config templates + SHA256:
    {root}\portal-ext.properties.template / .sha256
    {root}\portal-setup-wizard.properties.template / .sha256

## Endpoints (base http://localhost:8080)
- Headless Admin Content: /o/headless-admin-content/v1.0
- Headless Delivery: /o/headless-delivery/v1.0
- Headless Admin Site: /o/headless-admin-site/v1.0
- Headless Admin User: /o/headless-admin-user/v1.0
- MCP: /o/mcp
- KNOWN MCP GOTCHA — before ANY call that includes a `?filter=...` query
  (through the MCP tools or headless calls directly), read
  liferay-headless-skill's "Known issues / gotchas" section FIRST:
  Liferay's MCP server does strict, unencoded `new URI(...)` parsing and
  throws `URISyntaxException` on raw spaces/quotes in a filter value
  (e.g. `filter=name eq 'Navigation Item'`). Always percent-encode the
  filter value, or fetch unfiltered and match client-side. This is a
  platform limitation in `com.liferay.mcp.server`, not something any agent
  here can patch.

## Locales
- defaultLanguageId: en_US
- availableLanguageIds: en_US, ar_SA (Arabic is RTL; ar_SA is the localizable target)
- Every localizable field MUST carry both labels; select options MUST carry
  both labels too.
- Arabic labels come from the glossary (exact, case-insensitive match).
  A glossary miss produces "<English label> (AR)" + needsTranslation=true.
  NEVER machine-translate ad hoc — the "(AR)" marker is the contract that
  tells the gate and the translator what is pending.

## ERC scheme (MANDATORY, deterministic)
- Structure: QCDEMO-{storyId}-{STRUCTURE_KEY}
- Template:  QCDEMO-{storyId}-{STRUCTURE_KEY}-TPL (detail: ...-TPL-DETAIL)
- Article:   QCDEMO-{storyId}-{slug}
- Site:      QCDEMO-{storyId}-{friendlyUrlSlug} — for a rare per-story
  sub-site only. The one canonical project site (see next section) uses a
  FIXED exception ERC instead, because it is not story-scoped.
- User:      QCDEMO-{emailLocalPart}
Normalize: keys UPPERCASE, non-alnum -> '_'; slugs lowercase, non-alnum -> '-',
collapsed, trimmed, [a-z0-9-] only. Never embed translated text in an ERC.

## Canonical Qatar Chamber site (standing infrastructure)
Decided 2026-07-04 (run 20260704T144517Z-f205 surfaced this via HITL,
answer: yes — create it). This pipeline's content lives in ONE persistent,
shared site named "Qatar Chamber" — never Guest, never Global, and never a
fresh site per story.
- Fixed ERC (the documented exception to the per-story Site pattern above):
  QCDEMO-SITE-qatar-chamber
- friendlyURLMapping: /qatar-chamber
- name: { en_US: "Qatar Chamber", ar_SA: "<glossary lookup, else the
  standard '(AR)' fallback marker — never machine-translate the brand name
  ad hoc>" }
- membershipType: open (public chamber-of-commerce website)
- defaultLanguageId: en_US, availableLanguageIds: [en_US, ar_SA]
- Site owner permissions: the account that creates the site (the demo
  admin, test@liferay.com) MUST be granted the site's built-in Owner role
  at creation time, so later site-scoped role work (e.g. a story asking for
  "Site Content Editor" / "Site Content Author" roles, as QC-GBL-001 did)
  can be delegated without repeated instance-admin intervention. This is
  the one documented exception to liferay-headless-skill's "NEVER POST"
  golden rule: role/membership assignment is a relationship toggle, not an
  ERC-addressable resource, so it is treated as idempotent
  ("ensure has role X", noop if already assigned) rather than a POST.
- Idempotency: created at most once, by whichever run first needs it
  (GET-by-ERC 404 -> create; 200 -> reuse). Every later run targets this
  same groupId.
- Protected from rollback: the canonical site is standing, cross-run
  infrastructure, NOT scoped to any single run's lifecycle. Even if a run
  creates it, liferay-rollback-agent must never delete it — see its
  guardrails. Its compensation-log entry carries protected:true.
- Preflight looks for this site specifically by name/friendlyURL (not just
  "the first site returned"). If absent, preflight still resolves a
  read-only groupId fallback (Guest) with a warning, but also sets
  outputs.siteMissing=true. Plan derivation (Step 4) always targets this
  canonical site regardless of siteMissing — liferay-site-agent's own
  idempotent GET-by-ERC decides create vs. reuse. siteMissing is now
  informational/reporting only; it is standing pipeline policy, not a
  per-run judgment call routed to HITL by itself.

## Gate rules (two-tier)
Hard signals (any true -> HITL, regardless of score):
  intent=="other" | entities==0 | acceptanceCriteria<2 |
  distinct entities>5 | >30% translation-pending
Translation-pending ratio counts BOTH fields with needsTranslation==true
AND select options with needsTranslation==true, over (fields + options).
Step 4b recomputes this ratio from the derived plan and overwrites the
analyzer's heavy_translation signal if the recount crosses 30%.
Soft signal: confidenceScore < 0.80
requiresHITL = anyHardSignal || confidenceScore < 0.80 || risk=="high"
Note: which site to target is NO LONGER part of this judgment call (see
"Canonical Qatar Chamber site" above) — it is fixed, standing policy.

## Plan validation (Step 4b, blocking, before the gate)
PV-01..PV-10 per the orchestrator. Any BLOCK finding -> run terminal state
PLAN_INVALID: zero Liferay calls, no rollback needed, full report still
produced. Findings always written to plan-validation.json (empty array on
a clean pass).

## HITL tags on the PBI
- agentic-hold     : set by system when paused
- agentic-approved : human approves -> resume
- agentic-rejected : human rejects  -> abort + rollback

## Conventions
- All timestamps UTC ISO-8601.
- runId format: YYYYMMDDTHHMMSSZ-{4 hex}, e.g. 20260702T120005Z-9f3a.
- UPPER_SNAKE structure keys; camelCase field names; display names may
  contain spaces (e.g. "Member Profile").
- Acceptance criteria carry stable ids AC-1..AC-n in document order,
  assigned at fetch time; they flow into analysis entities and the plan's
  derivedFrom for end-to-end traceability.
- Every agent verifies phases.preflight.status=="done" before any Liferay
  MCP call.
- Every agent verifies it has read liferay-headless-skill's "Known issues /
  gotchas" section before constructing any `?filter=...` query against the
  MCP/headless tools (see "Endpoints" above).
