---
name: qatar-chamber-header-footer-master
description: Build the Qatar Chamber global Header and Footer page fragments and
  the QC Master page template (Header ▸ Drop Zone ▸ Footer) for Liferay DXP
  (quarterly LTS, e.g. 2026.Q1.9) directly from the Qatar Chamber Figma file.
  Encodes how to read the Figma design via the Figma MCP / REST, the fragment
  file layout and conventions (logical properties, Style Book tokens, i18n,
  inline-editable links, Object-driven logo/nav), the exact fragment-config and
  master page-definition import formats, the forward-slash zip requirement,
  the required Object creation order (HeaderConfiguration, FooterConfiguration,
  FooterLink, AccessibilityHeaderConfiguration) before importing the master,
  and every import failure we hit so it succeeds first time. Use when creating
  or updating the QC header/footer/master from Figma.
---

# Qatar Chamber Header / Footer / Master Page

Builds three artifacts from the Qatar Chamber Figma design and imports them into
the Liferay site:

1. `qc-global-site-header` fragment (logo + 3-level nav + actions)
2. `qc-global-site-footer` fragment (brand + link columns + newsletter + legal)
3. `QC Master` master page template = **Header ▸ Drop Zone ▸ Footer**

Architecture is **client-extension + fragments + Style Book** — NO WAR theme.

> **MANDATORY repo source-of-truth:** every fragment file AND every custom Object
> definition/entry you create here must live in committable repo files, never
> only in the running instance. Fragments →
> `build-resources/fragments/qc-website-sections/fragments/<key>/`; Objects (incl.
> HeaderConfiguration, FooterConfiguration, FooterLink, AccessibilityHeaderConfiguration,
> and the footer-redesign objects) → `build-resources/object-definitions/reprovision/`
> (`definitions/*.object.json` + `seeds/*.seed.json` + `assets/` + provisioner).
> A DB-only object is lost on delete and reverted by a re-provision — this gap
> forced a full teardown-and-rebuild recovery on 2026-07-12. See
> `qc-fragment-and-cx-deploy` and `liferay-headless-skill`.

> **Upstream tokens:** brand colors/fonts come from the **QC Style Book** — see
> the **`qatar-chamber-style-book`** skill. Fragments here consume its variables
> (`var(--primary)`, `var(--font-family-base)`, …), never hex literals. Create
> or update the Style Book first if a needed token is missing.

> **Downstream consumer:** the header's accessibility icon (T15) is only the
> trigger — the actual panel is a separate site-wide client extension built by
> the **`qatar-chamber-accessibility-tools`** skill. That skill also owns the
> `AccessibilityHeaderConfiguration` Object referenced below. Don't duplicate
> panel logic here if the icon's behavior needs changing.

## Canonical facts (this project)
- Liferay: DXP quarterly LTS (verified 2026.Q1.9), http://localhost:8080, admin
  `test@liferay.com` / `test`.
- Qatar Chamber site: friendlyURL `/qatar-chamber` (groupId is env-specific).
- Figma file: `Qatar Chamber`, fileKey **`J3e1thav8NIu6a3XhC6Wcl`**.
  - Home frame (EN): `849:15904`. Header component: `1367:16420`.
    Footer component set: `614:11071` (variants EN/AR × Desktop/Mobile).
- Repo source of truth:
  - `build-resources/fragments/qc-website-sections/` (collection + fragments)
  - `build-resources/fragments/qc-website-sections.zip` (import artifact)
  - `build-resources/master-page-templates/qc-master/` (master source)
  - `build-resources/master-page-templates/qc-master.zip` (import artifact)

## Step 0 — Read the Figma design

Figma MCP (Framelink `figma-developer-mcp`) is configured in
`C:\Users\bataw\.codeium\windsurf\mcp_config.json` with a personal access token.
If MCP tools aren't loaded, use REST directly (token works the same):

```powershell
$token='<FIGMA_PAT>'; $key='J3e1thav8NIu6a3XhC6Wcl'
# whole file tree (pages > frames):
Invoke-RestMethod "https://api.figma.com/v1/files/$key" -Headers @{'X-Figma-Token'=$token} -OutFile "$env:TEMP\qc_figma.json"
# specific nodes (header + footer):
Invoke-RestMethod "https://api.figma.com/v1/files/$key/nodes?ids=614:11071,1367:16420" -Headers @{'X-Figma-Token'=$token} -OutFile "$env:TEMP\qc_nodes.json"
```

Parse with PowerShell + `ConvertFrom-Json`; walk `.document`/node `children`
recursively, printing `type`, `name`, `characters` (TEXT), `fills[0].color`
(→ hex), and `style.fontSize/fontWeight`. Read the **EN Desktop** variant for
English text + measurements; AR variants confirm RTL + the maroon background.

Extracted footer facts (design tokens):
- Maroon variant bg `#911731` (use `var(--primary)`) with darker diagonal
  gradient + subtle geometric motif; charcoal `#1d1d1b` is the alt variant.
- Column heads white 16px/500; links `#d0d0d0`→white on hover, 14px/400 with a
  chevron marker; divider rgba-white; newsletter CTA = white bg, maroon text.
- Columns: **About Qatar Chamber** (About Us, Chairman's Message, Chamber's Law,
  Vision & Mission, Board of Directors, Organizational Structure) · **Services**
  (Membership, Certificate of Origin, B2B Registration, ATA Carnets, TIR
  Carnets, Training Programs) · **Quick Links** (Useful Links, Contact Us, Help
  Center, Career Opportunities, Tenders, FAQ's) · **Stay Updated** (newsletter).

## Fragment conventions (binding)
See `build-resources/fragments/README.md`. Key rules:
- Folder/key `qc-<area>-<name>` (area ∈ global|home|…). Files: `fragment.json`,
  `index.html`, `styles.css`, `main.js`, `configuration.json`.
- CSS scoped under `.qc-<area>-<name>`; **logical properties only**
  (`margin-inline`, `inset-inline-end`, `text-align:start`) so ar_SA mirrors
  for free. Consume Style Book vars (`var(--primary)`, `var(--font-family-base)`)
  — no hex literals for brand values; footer-specific colors go in private
  `--_footer-*` custom props on the root.
- Never hardcode English: text comes from configuration, an Object/headless
  call, `Liferay.Language.get()`, or an **inline-editable element**.

## Data contracts (single source of truth)

The header and footer each own **their own** logo Object — they are NOT
shared, despite looking like duplicates. This tripped us up once; don't
re-merge them.

- **Header logo**: `HeaderConfiguration` Object (ERC
  `QCDEMO-129363-HEADER_CONFIGURATION`, id `37439` this env) — `logoImage`
  (attachment), `logoAltTextEn/Ar`, `logoRedirectUrl`.
  `GET /o/c/headerconfigurations/scopes/{groupId}?pageSize=1`.
- **Footer logo**: its own fields on the **`FooterConfiguration`** Object
  (same object as the footer text below, NOT HeaderConfiguration) —
  `logoImage`, `logoAltTextEn/Ar`, `logoRedirectUrl`.
  `GET /o/c/footerconfigurations/scopes/{groupId}?pageSize=1`. Footer forces
  it white via CSS `filter: brightness(0) invert(1)`.
  There is currently no committed `setup-header-configuration.ps1` — the
  `HeaderConfiguration` Object was created ad hoc before the
  `object-definitions/` scripting convention existed. If it's missing in a
  fresh env, create it manually (Control Panel → Objects → New) with the four
  fields above, or write a script mirroring `setup-footer-objects.ps1`.
- **Nav** (header): `GET /o/c/navitems/scopes/{groupId}?filter=<url-encoded>activeStatus eq true&sort=displayOrder:asc`.
  `parentMenu` = parent's ERC (empty at level 1); build ≤3-level tree. Default
  bilingual top-level labels are seeded by `nav-item-seed.json` and
  `setup-nav-items.ps1` (mirrors `setup-footer-objects.ps1`).
- **Header accessibility icon visibility** (story 129364, T15): before showing
  the icon, `main.js` also checks the `AccessibilityHeaderConfiguration`
  Object's `accessibilityToolsEnabled` field —
  `GET /o/c/accessibilityheaderconfigurations/scopes/{groupId}?pageSize=1`;
  icon shows unless that field is explicitly `false` OR no entry exists yet
  (fails open when unconfigured, closed when explicitly disabled). The actual
  panel behavior lives in the **`qatar-chamber-accessibility-tools`** skill —
  this fragment only owns the icon and dispatches
  `document.dispatchEvent(new CustomEvent('qc:accessibility:toggle'))`.
- **Footer text** (column titles, about, social title, newsletter title/text,
  subscribe label, email placeholder, copyright): **FooterConfiguration Object**, one site-scoped
  entry with `...En`/`...Ar` field pairs:
  `GET /o/c/footerconfigurations/scopes/{groupId}?pageSize=1`. JS fills every
  `[data-qc-text="<field>"]` hook with the locale value. Placeholders use
  `[data-qc-placeholder="<field>"]` and are set via the `placeholder` attribute.
- **Footer link columns + legal**: **FooterLink Object** (mirrors NavItems):
  `GET /o/c/footerlinks/scopes/{groupId}?filter=<url-encoded>activeStatus eq true&sort=displayOrder:asc`.
  Fields `footerLinkLabelEn/Ar`, `footerLinkUrl`, `footerColumn` picklist
  (`about|services|quickLinks|legal`), `displayOrder`, `activeStatus`. JS groups
  by column into `[data-qc-footer-links="<column>"]`. HTML keeps EN defaults as
  pre-JS fallback.
- Object definitions + one-shot setup/seed scripts:
  `build-resources/object-definitions/`. `setup-nav-items.ps1` creates the
  `Nav Item Levels` picklist, publishes the `NavItem` object, and seeds the
  default bilingual top-level nav items. `setup-footer-objects.ps1` creates the
  `Footer Columns` picklist, injects its `listTypeDefinitionId` into FooterLink,
  publishes both objects (including the footer's own logo fields), and seeds a
  bilingual default entry + rows. `HeaderConfiguration` and
  `AccessibilityHeaderConfiguration` have no equivalent script yet (see gaps
  above and in `qatar-chamber-accessibility-tools`).
- **Footer social + newsletter**: fragment configuration (`facebookUrl`, `xUrl`,
  `linkedinUrl`, `instagramUrl`, `youtubeUrl`, `whatsappUrl`,
  `newsletterActionUrl`); JS hides social links with empty URLs.
- Grant **Guest: View** on ALL Objects the header/footer touch — `NavItem`,
  `HeaderConfiguration`, `FooterConfiguration`, `FooterLink`, and
  `AccessibilityHeaderConfiguration` (Control Panel → Objects → Permissions) —
  or anonymous visitors get 403 on that one call (header/footer/icon degrade
  to their HTML/JS defaults for just that piece, not a hard failure, but still
  wrong for a public site).

## THE FRAGMENT CONFIG FORMAT (get this exactly right)
`configuration.json` field `dataType` enum is limited. Common failures:
- **checkbox** fields must have **NO `dataType`** — `{ "name","label","type":"checkbox","defaultValue":true }`.
  `"boolean"` AND `"bool"` both fail with "dataType: … is not a valid enum value".
- `text` uses `"dataType":"string"`; `select` uses `"int"`/`"string"`.

## THE MASTER IMPORT FORMAT (get this exactly right)
Zip layout (import fragments FIRST — master references them by key):
```
qc-master/
  master-page.json        {"name": "QC Master"}
  page-definition.json
```
`page-definition.json` (verified working on 2026.Q1.9):
```json
{
  "pageElement": {
    "pageElements": [
      { "definition": { "fragment": { "key": "qc-global-site-header" }, "fragmentConfig": {} }, "type": "Fragment" },
      { "definition": { "fragmentSettings": { "unallowedFragments": [] } }, "type": "DropZone" },
      { "definition": { "fragment": { "key": "qc-global-site-footer" }, "fragmentConfig": {} }, "type": "Fragment" }
    ],
    "type": "Root"
  }
}
```
Rules that matter:
- Drop zone `type` is **`"DropZone"`** (one word), with
  `definition.fragmentSettings.unallowedFragments`. `"Drop Zone"` fails.
- **No top-level `"version"`.** No empty `editableValues`.
- Fragment `key` = fragment folder name (must already be imported).

## Building zips — FORWARD SLASHES REQUIRED
Windows `Compress-Archive` writes backslash entry paths → Liferay (Java) can't
read them. Build with `System.IO.Compression.ZipArchive` using `/` entry names,
and exclude `thumbnail.png` (see thumbnail gotcha):
```powershell
Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
function New-ZipFwd($srcDir,$zipPath,$rootName){
  if(Test-Path $zipPath){Remove-Item $zipPath -Force}
  $fs=[IO.File]::Open($zipPath,'Create'); $zip=New-Object IO.Compression.ZipArchive($fs,'Create')
  $base=(Resolve-Path $srcDir).Path
  Get-ChildItem $srcDir -Recurse -File | Where-Object {$_.Name -ne 'thumbnail.png'} | ForEach-Object {
    $rel=$_.FullName.Substring($base.Length).TrimStart('\','/').Replace('\','/')
    $e=$zip.CreateEntry("$rootName/$rel",'Optimal'); $s=$e.Open()
    $b=[IO.File]::ReadAllBytes($_.FullName); $s.Write($b,0,$b.Length); $s.Close()
  }
  $zip.Dispose(); $fs.Close()
}
New-ZipFwd '<repo>\build-resources\fragments\qc-website-sections' '<repo>\build-resources\fragments\qc-website-sections.zip' 'qc-website-sections'
New-ZipFwd '<repo>\build-resources\master-page-templates\qc-master' '<repo>\build-resources\master-page-templates\qc-master.zip' 'qc-master'
```

## Import + apply (UI)

The master page's header/footer fragments read from four Objects at render
time — **every one must exist and be published before importing the master**,
or the master will publish fine but render an empty/broken header or footer
for every page that uses it (fragments fail soft per-field, not per-page, so
it's easy to miss one field silently falling back to blank).

1. **Objects, in this order**:
   1. `setup-nav-items.ps1` (edit `$GroupId` first) — `NavItem` + picklist +
      seed rows. Drives the header nav tree.
   2. **`HeaderConfiguration`** — no script yet (see Data contracts above);
      create manually if missing: fields `logoImage` (attachment),
      `logoAltTextEn`, `logoAltTextAr`, `logoRedirectUrl`, then add one entry
      with the header logo.
   3. `setup-footer-objects.ps1` — `FooterConfiguration` (footer's **own**
      logo fields + all footer text) + `FooterLink` (nav-style link rows,
      grouped by the `Footer Columns` picklist) + seed content.
   4. **`AccessibilityHeaderConfiguration`** (story 129364) — only needed if
      the accessibility icon must be admin-toggleable; see
      `qatar-chamber-accessibility-tools`. If absent, the header fragment
      fails open and just always shows the icon.
2. **Fragments**: Design → Fragments → Options (⋮) → Import → `qc-website-sections.zip`.
3. **Master**: Design → Page Templates → **Masters** → Options (⋮) → Import →
   `qc-master.zip` → open **QC Master** → **Publish Master**.
4. **Apply**: page → Page Design Options → Master → **QC Master**; set it as the
   site default so new pages inherit it.
5. **Permissions**: grant Guest View on `NavItem`, `HeaderConfiguration`,
   `FooterConfiguration`, `FooterLink`, and `AccessibilityHeaderConfiguration`.
6. **Footer content**: set social/newsletter URLs in fragment settings; upload
   the footer logo in `FooterConfiguration` (not `HeaderConfiguration`).
7. **Verify end to end**: load a real published page (not just Control Panel)
   and confirm logo, nav, footer links, and (if configured) the accessibility
   icon all render for an anonymous/guest session — permission gaps only show
   up logged-out.

### UI fallback if a master zip is ever rejected
Masters → Add → drag **QC Site Header** above the Drop Zone, **QC Site Footer**
below → Publish. Then Export it to capture the exact page-definition for the repo.

## Troubleshooting (all hit on this project)
| Symptom | Cause | Fix |
|---|---|---|
| Figma 404 with `?depth=N` but file name known | odd query handling | call `/v1/files/{key}` without `depth`; `/v1/me` confirms token |
| Import warning `dataType: boolean/bool not a valid enum value` | checkbox has `dataType` | remove `dataType` from checkbox fields |
| `A file entry already exists with title 1_preview.png` | re-import recreates fragment preview | remove `thumbnailPath` + exclude `thumbnail.png` from zip (idempotent re-import) |
| Master: `page definition is invalid` | `"Drop Zone"`, empty drop-zone def, or top-level `version` | use `"DropZone"` + `fragmentSettings`, drop `version`/`editableValues` |
| Fragments/master import silently mangled | backslash zip entries | rebuild zip with forward-slash entries |
| Empty header/logo for guests | Object permissions | grant Guest View on Nav Item + Header Configuration (+ FooterConfiguration/FooterLink/AccessibilityHeaderConfiguration for the rest) |
| Footer logo blank but header logo fine (or vice versa) | assumed a shared logo Object — header and footer each have their own `logoImage` field on separate Objects (`HeaderConfiguration` vs `FooterConfiguration`) | set the logo on the correct Object; don't try to point both fragments at one endpoint |
| Accessibility icon never shows even though the panel CX works | `AccessibilityHeaderConfiguration` Object missing or has `accessibilityToolsEnabled=false`, or Guest View not granted | create the entry / set the field true, or grant Guest View — see `qatar-chamber-accessibility-tools` |
