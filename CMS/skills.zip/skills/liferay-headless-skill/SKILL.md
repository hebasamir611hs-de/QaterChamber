---
name: liferay-headless-skill
description: Idempotent-by-ERC write protocol for Liferay DXP headless APIs / MCP,
  compensation logging for safe rollback, extended field-type mapping,
  validation and options mapping, i18n pattern, and error handling.
---

# Liferay Headless Skill

## Golden rule
NEVER POST. Every mutation is an idempotent PUT by ERC, preceded by a GET that
captures prior state for rollback.
EXCEPTION (documented, not a license to improvise): if a resource type has
NO working by-external-reference-code route in the target instance/version
— see "Endpoints" below, Structure is the currently known case — an agent
MUST NOT fall back to guessing a POST/PUT sequence. It must (a) use the
verified read-only existence check documented for that resource as a
substitute existence check, (b) still honor dryRun (plan and log a noop,
never attempt a live write), and (c) fail the phase with a clear error
(e.g. ENDPOINT_UNVERIFIED) rather than silently POSTing if a live
(non-dry-run) write is ever attempted before the real mutation route is
confirmed for that instance/version.

## Repo source-of-truth for Object definitions (MANDATORY)
Never leave a custom Object definition or its entries living only in the
running instance. Every definition you create/change and every entry you write
MUST be mirrored into committable repo files, in the same change, and committed —
the DB is not a backup, and a re-provision from stale files silently reverts
live work (a DB-only set of objects forced a full teardown-and-rebuild recovery
on the QC project, 2026-07-12).

Canonical location (QC project): `build-resources/object-definitions/reprovision/`
- `definitions/<Name>.object.json` — create-ready definition: strip read-only
  props (`restContextPath`, `active`, `id`), keep correct `localized` flags, and
  set `friendlyURLSeparator` explicitly if the auto-derived one ever collides
  (publish returns 400 `ObjectDefinitionFriendlyURLSeparatorException` /
  "Other asset types may use this prefix").
- `seeds/<Name>.seed.json` — entries keyed by ERC with full
  `{"__i18n":{"en_US":...,"ar_SA":...}}` maps for localized fields and
  `{"__attachment":"assets/..."}` refs for Attachment fields.
- `assets/` — attachment binaries; `manifest.json` + an idempotent-by-ERC
  provisioner (`setup-all-objects.mjs`).

Export/seed with node fetch, NEVER curl (curl mangles inline Arabic UTF-8).
Gotchas that MUST be encoded in these files/scripts:
- A field's `localized` flag is **immutable after creation** (PUT returns 500,
  UI greys the checkbox) — to localize an existing field you delete + recreate
  it, so the committed definition must carry the intended flag from the start.
- The `<field>_i18n` PATCH **replaces** the whole locale map — always send every
  locale you want to keep (`{"en_US":...,"ar_SA":...}`), never one locale alone.
- Create is a POST + a separate `/publish`; delete a definition only by numeric
  id (DELETE by-external-reference-code returns **405**).

## Known issues / gotchas
- **Percent-encode filter query values before calling MCP/headless tools.**
  Liferay's MCP server (`MCPServerServlet._call` ->
  `HttpImpl.URLtoString` -> `HttpComponentsUtil.getURI` -> `new URI(...)`)
  does strict URI parsing and does NOT percent-encode the query string
  itself. A raw filter like `filter=name eq 'Navigation Item'`
  (unencoded space/quotes) throws `URISyntaxException`. Always encode:
  `filter=name%20eq%20%27Navigation%20Item%27`, or fetch unfiltered and
  match client-side. Related HTTP 404s in logs are often the same
  malformed/unencoded calls, not "resource not found." This is a platform
  limitation in `com.liferay.mcp.server`, not fixable from this codebase —
  a future module upgrade may resolve it. Verified while investigating the
  Structure endpoint gap below (2026-07-04); apply this encoding rule to
  EVERY `?filter=...` call any agent makes through the MCP tools, not just
  content-structures lookups.
- **Every `scope: "site"` custom Object's entry collection MUST be addressed
  via `/o/c/{restContextPath}/scopes/{groupId}`, never the bare
  `/o/c/{restContextPath}`.** The bare form returns HTTP 409 ("Conflict with
  getObjectEntriesPage"), not 404, for GET, and the same applies to POST for
  creating an entry. This generalizes the pattern already used ad hoc for
  FooterConfiguration/FooterLink/NavItem (see
  qatar-chamber-header-footer-master) to ANY site-scoped Object Definition —
  confirmed 2026-07-07 against a freshly created Object (Subscriber,
  story 129566), so it's not specific to those four Objects.
- **A `required: true` Boolean object field cannot be explicitly set to
  `false` via PATCH or PUT on this instance** — both return 400 "No value was
  provided for required object field '<name>'", even when every required
  field is present in the body. Confirmed 2026-07-07 on Subscriber's
  subscriptionStatus field. If a flow needs to flip a required boolean back
  off (e.g. an unsubscribe/deactivate action), do not fight this: either
  model the flip as a DELETE of the entry (works fine, and is often the more
  literal interpretation of "remove/deactivate" anyway), or make the field
  `required: false` at design time if an explicit `false` must survive a
  PATCH/PUT. Not yet confirmed whether this is instance-specific or a general
  DXP 2026.Q1.9 Object Admin bug — re-verify before assuming it's fixed on a
  different instance.

## Verification duty (read first, every new instance/version)
Endpoint availability is NOT guaranteed to match this skill across Liferay
versions/instances — it drifted at least once already (see "Endpoints"
below). Before any agent's FIRST live write of a given resource type
against a given instance, live-verify the endpoint actually exists (GET the
OpenAPI spec for the relevant headless module, or attempt the documented
GET and confirm it is not a generic 404-for-unknown-route). If it does not
match this skill, do not guess a replacement — log ENDPOINT_UNVERIFIED /
SKILL_ENDPOINT_MISMATCH, fail the phase (or stay in dry-run noop), and
surface it for a human to update this skill file, the same way
2026-07-04T17:10:00Z's correction pass did for content-structures. Also
remember the percent-encoding gotcha above when constructing that
verification GET — an unencoded filter will throw before you even learn
whether the resource route exists.

## Authentication
Header: Authorization: Basic <base64(email:password)> for the demo admin
test@liferay.com. Content-Type: application/json.
This works because portal-ext.properties includes /o/* in
BasicAuthHeaderAuthVerifier.urls.includes. The same Basic credential pair is
what the Liferay MCP server consumes via the npx mcp-remote bridge against /o/mcp.

## The write protocol (MANDATORY for every mutation, resources WITH a
## confirmed by-ERC route — Template, Article, Site, User, Object Definition,
## List Type Definition; NOT Structure, see below)
1. Compute the ERC per shared-context.
2. GET .../by-external-reference-code/{erc}
   - 404 -> priorState = null, action = "created"
   - 200 -> priorState = FULL response body (never a summary), action = "updated"
3. If state.input.dryRun == true:
   Do NOT PUT. action = "noop". Write the planned body to
   runs/{runId}/artifacts/. Continue to step 4.
   Else: PUT .../by-external-reference-code/{erc} with the desired body.
4. On success (2xx, or the noop decision), appendCompensation(runId, {
   resourceType, erc, id: <resource id or null>, action, priorState,
   endpoint, at: nowUtc() })

## Endpoints
- Structure: **CONFIRMED DEAD END — re-verified 2026-07-05T06:48:00Z by
  fetching this instance's LIVE OpenAPI specs (not just probing a URL).**
  `/o/headless-admin-content/v1.0/openapi.yaml` has NO content-structures
  path at all (that module here only exposes structured-contents,
  display-page-templates, page-definitions). `/o/headless-delivery/v1.0/openapi.yaml`
  DOES define content-structures paths —
  `/v1.0/sites/{siteId}/content-structures`,
  `/v1.0/content-structures/{contentStructureId}`,
  `/v1.0/asset-libraries/{assetLibraryId}/content-structures` — but every
  single one declares a `get` operation ONLY. There is no `post`, `put`, or
  `delete` anywhere for this resource, and no by-external-reference-code
  sub-route. This is settled, not merely unconfirmed: **do not spend further
  agent time "re-verifying" Structure** — there is no mutation route to find
  in this instance. liferay-structure-agent stays plan-only/noop for
  Structure permanently, and must fail the phase with a terminal error
  (not a retry) if a live write is ever demanded.
    GET /o/headless-delivery/v1.0/sites/{siteId}/content-structures
      (200; supports ?filter=name eq '{name}' — confirmed working, use this
      as the read-only existence check for planning purposes. Remember to
      percent-encode the filter value per "Known issues / gotchas" above —
      the unencoded form throws URISyntaxException in Liferay's MCP server
      before the request even reaches the resource.)
  **Verified alternative:** for a plan entity flagged objectsCandidate=true
  (self-referencing hierarchy, ordering, status flags, or a
  draft/publish/workflow lifecycle — see shared-context's Objects-vs-
  structures rubric), Liferay Objects (below) are the recommended live
  target instead, and their by-ERC route is fully confirmed working. Which
  target a story uses is a plan-derivation (Step 4) decision, not something
  an executor agent should switch to on its own initiative.
- Object Definition: **VERIFIED WORKING 2026-07-05T06:48:00Z** against
  `/o/object-admin/v1.0/openapi.yaml`.
  GET/PUT `/o/object-admin/v1.0/object-definitions/by-external-reference-code/{erc}`
  — a full by-ERC route matching the standard write protocol above exactly
  (fields, including `objectFields[]`, can be embedded directly in the same
  PUT body; no separate per-field call is required for initial creation).
  A newly created/updated object definition is NOT active until published:
  follow the PUT with `POST /o/object-admin/v1.0/object-definitions/{objectDefinitionId}/publish`
  using the numeric `id` from the PUT response. Whether entries can be
  created against an unpublished definition was not independently tested —
  always publish before assuming the definition is usable, per "Verification
  duty".
- List Type Definition (backs Picklist/MultiselectPicklist option sets on
  Object fields): **VERIFIED WORKING 2026-07-05T06:48:00Z** against
  `/o/headless-admin-list-type/v1.0/openapi.yaml`.
  GET/PUT `/o/headless-admin-list-type/v1.0/list-type-definitions/by-external-reference-code/{erc}`.
  For a small fixed option set, embed entries directly in the PUT body as
  `listTypeEntries: [{ key, name_i18n: { en_US, ar_SA } }]` — no separate
  call needed. An Object field references the definition by
  `listTypeDefinitionExternalReferenceCode`, NOT by an inline `options`
  array (that shape is specific to DDM/Structure fields).
- Template:  /o/headless-admin-content/v1.0/structures/{structureId}/structured-content-templates/by-external-reference-code/{erc}
  (not yet independently re-verified against this instance — re-verify
  before first live use, per "Verification duty" above.)
- Article:   /o/headless-delivery/v1.0/sites/{siteId}/structured-contents/by-external-reference-code/{erc}
  (not yet independently re-verified against this instance — re-verify
  before first live use.)
- Site:      /o/headless-admin-site/v1.0/sites/{siteExternalReferenceCode}
  (**CORRECTED 2026-08-11.** There is NO `by-external-reference-code` segment
  under `/v1.0/sites` — confirmed against the live `openapi.json` path list.
  The ERC goes straight in the path slot. Live-verified 200 for
  `.../v1.0/sites/QCDEMO-SITE-qatar-chamber` (id 37246). The earlier
  2026-07-04 "404 = not yet created" reading was a route-level 404 being
  misread as a resource-level one.)
- User:      /o/headless-admin-user/v1.0/user-accounts/by-external-reference-code/{erc}
  (not yet independently re-verified against this instance.)
- Document Folder: **VERIFIED WORKING 2026-07-07.** NO by-ERC route exists
  (checked live against `/o/headless-delivery/v1.0/openapi.json` — only
  `GET/PUT/PATCH/DELETE /v1.0/document-folders/{id}` and
  `POST /v1.0/sites/{siteId}/document-folders` or
  `POST /v1.0/document-folders/{parentId}/document-folders` to create).
  This is a documented EXCEPTION per the Golden rule: idempotency substitute
  is `GET /o/headless-delivery/v1.0/sites/{siteId}/document-folders` (or
  the parent folder's `/document-folders` child listing), match by `name`
  client-side (percent-encode any `?filter=` per the gotcha above if you
  filter instead of fetching-and-matching), then POST only if absent.
  See "Feature asset organization" below for the required folder shape.
- Document (move into a folder) / Document (create in a folder):
  **VERIFIED WORKING 2026-07-07**, but both
  `PATCH /o/headless-delivery/v1.0/documents/{id}` and
  `POST /o/headless-delivery/v1.0/document-folders/{folderId}/documents`
  require `multipart/form-data`, NOT `application/json` — a plain JSON
  body 415s. The multipart shape is a `document` part (JSON, e.g.
  `{"documentFolderId": 40092}` to move, or `{"title": "..."}` to name on
  create) plus a `file` part (binary; omit when only moving an existing
  document). Discoverable live via `PatchDocumentRequestBody` /
  `PostDocumentFolderDocumentRequestBody` in the same OpenAPI doc.

## Feature asset organization (Documents and Media)
Every feature that uploads real images/icons into Documents and Media
(banner slides, counters, structured cards, etc.) gets its own folder,
nested under one fixed top-level folder — never loose at the site DL root
and never mixed with another feature's assets:
```
qatar-chamber-website/            <- fixed top-level folder, create once, reuse forever
  <feature-slug>/                 <- one per feature, e.g. "hero-banner"
    <asset-name>.<ext>            <- EN / locale-neutral asset
    <asset-name>-AR.<ext>         <- Arabic-named sibling, SAME extension
```
`<feature-slug>` = kebab-case, matching the fragment/entity name (e.g. the
Hero Banner feature -> `hero-banner`, mirroring its fragment key
`qc-home-hero-banner` minus the `qc-home-` prefix — use judgement to keep
it short and recognizable, not the literal fragment key).
Naming rule: for every asset, if a locale-specific Arabic variant is
uploaded, name it `<same base name as the English/neutral asset>-AR.<same
extension>` — never a different base name or extension. When the
underlying Object field is a single non-localized Attachment (the common
case: one `bannerImage`/`counterIcon` field serving both `en_US`/`ar_SA`
text on the same entry, per this project's Object field mapping), there is
no separate Arabic CONTENT to source — upload a byte-identical `-AR` copy
purely for this naming convention/symmetry, and do not repoint the object
entry's Attachment field at it (it still references the original file;
the duplicate exists for organizational clarity only, e.g. for a human
scanning the DL browser). If a field genuinely IS localized per-locale
(rare — check `localized: true` on the object field), the `-AR` file is
real distinct Arabic content and the entry's Arabic-locale value should
reference it instead.

## Structure field mapping (plan type -> Liferay fieldType / dataType)

| plan type    | fieldType        | dataType         | notes |
|--------------|------------------|------------------|-------|
| text         | text             | string           | — |
| textarea     | text_area        | string           | — |
| html         | rich_text        | string           | — |
| date         | date             | date             | — |
| number       | numeric          | double           | validation.min/max -> range expression |
| boolean      | checkbox         | boolean          | — |
| image        | image            | image            | — |
| url          | text             | string           | apply URL pattern validation |
| select       | select           | string           | options[] -> DDMFormFieldOptions; every option label carries en_US + ar_SA; order preserved |
| document     | document_library | document-library | reference doc folders by ERC, never raw folderId |
| geolocation  | geolocation      | geolocation      | NO validation object permitted (PV-04); Liferay owns lat/lng bounds |
| link_to_page | link_to_page     | link-to-page     | target resolved by friendlyURL at execution; unresolved -> retryable, max 2 retries, then fail phase (triggers rollback) |

## Validation mapping
- validation.pattern            -> DDMFormFieldValidation { expression: match(...) } with localized errorMessage
- validation.min / max (number) -> range expression
- validation.max (text/textarea)-> maxLength
- select, boolean, image, document, geolocation: any validation object is
  rejected upstream by PV-04; this skill must never silently drop or default one.

## Options payload shape
"options": { "en_US": { "value1": "Label" }, "ar_SA": { "value1": "..." } }
Build both locale maps from the plan's option.label objects. Never emit an
option with a missing locale.

## Object field mapping (plan type -> ObjectField businessType / DBType)
Only relevant once a plan entity targets Object Definition rather than
Structure (see "Endpoints" above). `businessType` and `DBType` are both
required on an ObjectField; the schema does not declare which pairs are
valid together, so treat every row below as best-effort until the first
live PUT confirms it (per "Verification duty") — expect a possible 422 on
first use of a row not yet exercised.

| plan type    | businessType        | DBType    | notes |
|--------------|----------------------|-----------|-------|
| text         | Text                 | String    | — |
| textarea     | LongText             | Clob      | unverified DBType pairing |
| html         | RichText             | Clob      | unverified DBType pairing |
| date         | Date                 | Date      | — |
| number       | Integer or Decimal   | Integer or BigDecimal | pick Integer/Integer when validation has no decimals implied, else Decimal/BigDecimal |
| boolean      | Boolean              | Boolean   | — |
| url          | Text                 | String    | no dedicated URL businessType; enforce the pattern via an objectValidationRules regex expression, mirroring the Structure url->text convention |
| select       | Picklist             | String    | requires a List Type Definition created first (see "Endpoints"); field references it via listTypeDefinitionExternalReferenceCode, not inline options |
| image, document | Attachment        | String (DBType is actually `Long`, not `String`, on live-verified fields) | **VERIFIED WORKING 2026-07-07.** `objectFieldSettings` MUST include `acceptedFileExtensions` WITHOUT leading dots (e.g. `"jpg, jpeg, png"`, NOT `".jpg,.jpeg,.png"`) — the platform compares the bare extension string, so a dot-prefixed value causes every upload to fail with "invalid extension" on BOTH REST and the Admin UI, even though the file itself uploads fine into Documents and Media first. If a field was created with dots already, `PATCH /o/object-admin/v1.0/object-fields/{id}` to fix it before the first live upload. To upload: PUT/PATCH the object entry with the field value as `{"fileBase64": "<base64, no data-URI prefix>", "name": "file.png"}`, or `{"id": <existing DLFileEntry id>}` to reference an already-uploaded file. Discover the exact nested shape per-resource via `GET /o/c/{resource}/openapi.yaml` and grep the field's `$ref` (resolves to the shared `FileEntry` schema). See `qc-object-attachment-field-extension-bug` memory for the full incident. |
| geolocation, link_to_page | — (unsupported) | — | Objects has no equivalent businessType for either; a plan field of this type cannot be provisioned as an Object field — log SKILL_ENDPOINT_MISMATCH for that field specifically and keep it plan-only even when the rest of the entity provisions live |

## Localization
- Localizable values are objects: { "en_US": "...", "ar_SA": "..." }
- Structures/sites: defaultLanguageId=en_US, availableLanguageIds=[en_US, ar_SA].
- Article contentFieldValue uses data_i18n keyed by locale.

## Pagination (reads)
Query params: page (1-based), pageSize (default 20, max 100).
Envelope: { items, page, pageSize, totalCount, lastPage }.

## Error handling
- 401 -> LIFERAY_AUTH_REGRESSION: halt run; operator re-runs preflight.
- 404 on GET during protocol step 2 -> normal ("created" path), NOT an error.
- 404 on a GET whose route is absent from the instance's deployed OpenAPI
  spec entirely (not just "resource not found") -> NOT the normal created
  path; this is SKILL_ENDPOINT_MISMATCH / ENDPOINT_UNVERIFIED — log it,
  fail the phase (or stay dry-run noop), do not treat as "created".
- URISyntaxException (or an unexpected 404/500 immediately on a call
  containing `?filter=...`) -> check "Known issues / gotchas" first: this
  is very likely an unencoded filter value, not a missing resource. Encode
  and retry before concluding the endpoint itself is broken.
- 422 -> validation failure: log the FULL response body, do NOT retry, fail
  phase. (With plan validation in place a 422 usually indicates PV coverage
  drift — report it as such.)
- 5xx -> retry up to 3 times with backoff (1s, 2s, 4s), then fail phase.

## Deletion (rollback only)
- DELETE .../by-external-reference-code/{erc}
- 404 on delete = already gone = success (idempotent).
- No agent other than liferay-rollback-agent may ever DELETE.
- Never applicable to a resource type whose by-ERC route is unverified
  (currently: Structure) — rollback of a noop entry is itself a noop
  regardless.
