---
name: state-management-skill
description: Read/write per-run state, the compensation log, and plan-validation
  findings for the Qatar Chamber demo. All operations are runId-scoped and
  schema-validated.
---

# State Management Skill

## Paths
- root = C:\temp\demo-ih-cache
- pointer = {root}\current-run
- runDir(id) = {root}\runs\{id}
- statePath(id) = {runDir}\state.json
- schemas = {root}\schemas\*.json

## runId
- Format: YYYYMMDDTHHMMSSZ-{4 hex} e.g. 20260702T120005Z-9f3a
- The 4-hex suffix guarantees uniqueness for parallel runs initiated in the
  same second.

## Functions (conceptual signatures)
- getCurrentRun() -> string | null        (reads pointer file)
- setCurrentRun(runId)                    (writes pointer file)
- initState(runId, input) -> state        (creates runDir, writes fresh state)
- readState(runId) -> state               (reads + validates vs state.schema.json)
- writeState(runId, next)                 (validates then writes atomically)
- patchPhase(runId, name, patch)          (merge into state.phases[name];
                                           set startedAt on first "running",
                                           finishedAt on done/failed/skipped)
- appendError(runId, {code, message})     (push to state.errors with timestamp)
- appendCompensation(runId, entry)        (validate vs compensationEntry
                                           schema, assign monotonic seq, push)
- archiveArtifact(runId, name, content) -> path
                                          (write to runs/{runId}/artifacts/{name};
                                           used for dry-run planned bodies and
                                           the reporter's rendered markdown)
- writePlanValidation(runId, findings)    (write runs/{runId}/plan-validation.json;
                                           always written, empty findings on
                                           a clean pass)

## Fresh state template
{
  "runId": "<id>",
  "createdAt": "<iso>",
  "input": { "storyId": "<id>", "dryRun": false },
  "story": null,
  "analysis": null,
  "hitl": null,
  "phases": {
    "preflight":         { "status": "pending" },
    "fetch":             { "status": "pending" },
    "analysis":          { "status": "pending" },
    "orchestration":     { "status": "pending" },
    "execute.site":      { "status": "pending" },
    "execute.structure": { "status": "pending" },
    "execute.article":   { "status": "pending" },
    "execute.user":      { "status": "pending" },
    "rollback":          { "status": "pending" },
    "implementation":    { "status": "pending" },
    "report":            { "status": "pending" }
  },
  "compensationLog": [],
  "report": null,
  "errors": []
}

## Rules
- Every write validates against the schema; reject invalid writes with
  appendError(code="SCHEMA_VIOLATION").
- appendCompensation assigns seq = (max existing seq) + 1, starting at 0.
- Writes are atomic: write to a temp file then rename.
- Never mutate state.json in place; always read -> modify -> writeState.
- All timestamps ISO-8601 UTC.