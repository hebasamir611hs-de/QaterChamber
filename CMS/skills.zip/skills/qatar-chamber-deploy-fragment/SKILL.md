---
name: qatar-chamber-deploy-fragment
description: Deploy Qatar Chamber website fragments and master page templates into
  Liferay DXP. Covers building the forward-slash zip, importing the fragment
  collection, importing the master page, publishing, and common import failures.
---

# Qatar Chamber Fragment & Master Page Deployment

Deploys the `qc-website-sections` fragment collection and the `QC Master` master
page template into a local Liferay DXP instance (quarterly LTS, verified on
2026.Q1.9).

## Canonical facts (this project)

- Liferay base URL: `http://localhost:8080`
- Qatar Chamber site: friendlyURL `/qatar-chamber`, groupId `37246` (env-specific)
- Fragment collection zip:
  `build-resources/fragments/qc-website-sections.zip`
- Master page template zip:
  `build-resources/master-page-templates/qc-master.zip`
- Fragment source folder:
  `build-resources/fragments/qc-website-sections/`
- Master page source folder:
  `build-resources/master-page-templates/qc-master/`
- Object definitions + data source of truth:
  `build-resources/object-definitions/reprovision/` (see
  `liferay-headless-skill` and `qc-fragment-and-cx-deploy`)

## MANDATORY: repo source-of-truth for fragments AND objects

Never deploy a fragment edit that exists only in the running instance. The
`build-resources/fragments/qc-website-sections/` source folder IS the source of
truth — edit the fragment's `index.html`/`styles.css`/`main.js` there FIRST,
then build the zip from it and import. If you ever patched live code directly,
pull the deployed `FragmentEntry` code back into the source folder before
committing. Rebuild the zip from the folder (forward-slash entries required:
`zip -r qc-website-sections.zip qc-website-sections`) so the committed zip and
folder always match.

Same rule for the custom Objects the fragments read: every Object definition
and its entries must be exported to
`build-resources/object-definitions/reprovision/` and committed (see
`liferay-headless-skill`). A DB-only object is lost on delete and reverted by a
re-provision; on the QC project this gap forced a full teardown-and-rebuild
recovery (2026-07-12).

## Build the deployable zips

### From the repo root (recommended)

```powershell
gradlew.bat buildClientExtensions
```

This runs the tasks defined in `client-extensions/build.gradle`:

- `buildFragmentZip` → `build-resources/fragments/qc-website-sections.zip`
- `buildMasterZip` → `build-resources/master-page-templates/qc-master.zip`

### Build only the fragment zip

```powershell
gradlew.bat :client-extensions:buildFragmentZip
```

### Build only the master page zip

```powershell
gradlew.bat :client-extensions:buildMasterZip
```

### PowerShell fallback (if Gradle is unavailable)

```powershell
# Fragment zip
powershell -ExecutionPolicy Bypass -File build-resources\build-fragment-zip.ps1

# Master page zip
powershell -ExecutionPolicy Bypass -File build-resources\build-master-zip.ps1

# Both
powershell -ExecutionPolicy Bypass -File build-resources\build-all-zips.ps1
```

All scripts use `System.IO.Compression.ZipArchive` with forward-slash (`/`) entry
names. **Never** use Windows `Compress-Archive` — it writes backslashes, which
break Liferay/Java imports.

## Fragment zip layout

```
qc-website-sections/
  collection.json
  fragments/
    qc-global-site-header/
      configuration.json
      fragment.json
      index.html
      main.js
      styles.css
    qc-global-site-footer/
      ...
    qc-home-hero-banner/
      ...
    qc-home-strategic-partners/
      ...
```

Fragment keys equal the folder names (e.g. `qc-global-site-header`). The master
page references these keys.

## Master page zip layout

```
qc-master/
  master-page.json
  page-definition.json
```

`master-page.json`:

```json
{
	"name": "QC Master"
}
```

`page-definition.json` root (no top-level `version`):

```json
{
	"pageElement": {
		"pageElements": [
			{
				"definition": {
					"fragment": {
						"key": "qc-global-site-header"
					},
					"fragmentConfig": {}
				},
				"type": "Fragment"
			},
			{
				"definition": {
					"fragmentSettings": {
						"unallowedFragments": []
					}
				},
				"type": "DropZone"
			},
			{
				"definition": {
					"fragment": {
						"key": "qc-global-site-footer"
					},
					"fragmentConfig": {}
				},
				"type": "Fragment"
			}
		],
		"type": "Root"
	}
}
```

- `type` for the drop zone is `DropZone` (one word, NOT `Drop Zone`).
- Fragment elements must NOT include empty `editableValues`.

## Import order

**1. Import fragments first.** The master page references fragment keys; if the
fragments are missing, the master page import will fail or show placeholders.

**2. Import the master page second.**

## Import fragments (UI)

1. Go to the Qatar Chamber site → **Design → Fragments**.
2. Open the **QC Website Sections** collection (or create it if this is the first
   import).
3. Click the **⋮** menu on the collection → **Import**.
4. Select `qc-website-sections.zip`.
5. Keep **Overwrite Existing Fragment** checked (idempotent re-import).
6. Click **Import**.
7. Expected result: all fragments import with no warnings. If a warning appears,
   see Troubleshooting below.

## Import master page template (UI)

1. Go to **Design → Page Templates → Masters**.
2. Click **Options (⋮)** → **Import**.
3. Select `qc-master.zip`.
4. Click **Import**.
5. Open **QC Master** → click **Publish** (imports are not live until published).

## Verify after import

### Fragments

- Open the collection and confirm every fragment is listed:
  - `QC Global Site Header`
  - `QC Global Site Footer`
  - `QC Home Hero Banner`
  - `QC Home Strategic Partners`
- Open a fragment and check the **Preview** tab renders without errors.

### Master page

- Go to **Design → Page Templates → Masters**.
- **QC Master** should show the header, drop zone, and footer in the editor.
- Publish the master page if it is in draft state.

### Page assignment

- Create or edit a page → **Page Design Options (brush icon)** → **Master** →
  select **QC Master**.
- View the page in both English and Arabic to verify RTL mirroring and fonts.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Import fails: zip is invalid | Backslash entry paths (`\`) from `Compress-Archive` | Use the Gradle tasks or the provided PowerShell scripts |
| Fragment imported but preview is blank | `configuration.json` has an invalid `dataType` for a checkbox | Checkbox fields must be `{name, label, type, defaultValue}` only — no `dataType` |
| Warning: `FreeMarker syntax is invalid... can't convert boolean to string` | A checkbox value is interpolated directly (`${configuration.myBool}`) | Use `${configuration.myBool?c}` or `${configuration.myBool?then('true','false')}` |
| Master page import fails: fragment not found | Fragments were not imported before the master page | Import `qc-website-sections.zip` first, then `qc-master.zip` |
| Master page shows empty drop zone | `type` is `Drop Zone` (two words) instead of `DropZone` | Use `"type": "DropZone"` |
| Master page import: `version` field error | `page-definition.json` has a top-level `version` | Root must be `{"pageElement": {"pageElements": [...], "type": "Root"}}` |
| Fonts not rendering | `qc-frontend` client extension (global CSS) not deployed | Deploy the `qc-frontend` client extension so `qc-global.css` loads the Cairo `@font-face` |
| Header/Footer content is missing | Liferay Objects (`NavItem`, `FooterConfiguration`, `FooterLink`, `HeaderConfiguration`) not seeded or missing Guest VIEW permission | Run the setup scripts in `build-resources/object-definitions/` and grant Guest VIEW |

## Automate the UI imports with Playwright

Because Liferay has no public headless API for fragment-collection zip imports,
this repo includes Playwright scripts that drive the admin UI:

- `automation/scripts/lib/liferay-helpers.js` — shared login, browser launch,
  and error-screenshot helpers
- `automation/scripts/import-fragments.js` — imports `qc-website-sections.zip`
- `automation/scripts/import-master.js` — imports `qc-master.zip`

Setup:

```powershell
cd automation
npm install
Copy-Item .env.example .env
# edit .env with credentials, zip paths, and PLAYWRIGHT_HEADLESS
```

Run:

```powershell
npm run import-fragments
npm run import-master
```

### Browser mode

Scripts default to **headless** (`PLAYWRIGHT_HEADLESS=true`). Set it to `false`
to watch the browser while debugging selectors:

```ini
PLAYWRIGHT_HEADLESS=false
```

### Known-good URLs (Liferay DXP 2026.Q1.9)

Replace `{SITE_FRIENDLY_URL}` with the value in `.env` (`qatar-chamber` by default).

| Destination | URL pattern |
|---|---|
| Entry point after login | `/en/web/{SITE_FRIENDLY_URL}` (configurable via `LIFERAY_ENTRY_PATH`) |
| Control Panel (authenticated) | `/group/{SITE_FRIENDLY_URL}/~/control_panel/manage` |
| Fragments admin path | Entry URL → Control Panel → Product Menu → Site Builder → Fragments |
| Master page import path | Entry URL → Control Panel → Product Menu → Site Builder → Page Templates → Masters tab |

Scripts land on the public site after login, then navigate to the Control Panel
URL (which works for authenticated sessions), and finally use the Product Menu
to reach the specific admin pages.

### Known-good selectors

| Element | Selector |
|---|---|
| Login username input | `input[name="_com_liferay_login_web_portlet_LoginPortlet_login"]` |
| Login password input | `input[name="_com_liferay_login_web_portlet_LoginPortlet_password"]` |
| Login submit button | `button[type="submit"]` |
| User avatar menu (public page) | `.user-avatar-link`, `[data-qa-id="userAvatar"]`, `.portlet-user-personal-bar .dropdown-toggle` |
| Control Panel link in user menu | `.dropdown-menu a:has-text("Control Panel")` |
| Fragment collection card | `.fragment-collection:has-text("QC Website Sections")` |
| Collection actions menu | `.fragment-collection .dropdown-toggle` |
| Collection Import item | `.dropdown-menu:visible .dropdown-item:has-text("Import")` |
| File input in import modal | `input[type="file"]` |
| Modal Import button | `.modal-footer .btn-primary:has-text("Import")` |
| Masters tab | `nav.navbar-underline a:has-text("Masters")` |
| Page Templates Options menu | `.management-bar .dropdown-toggle` |
| Page Templates Import item | `.dropdown-menu:visible .dropdown-item:has-text("Import")` |

If a selector breaks, use the visible browser mode to inspect the live markup,
then update the selector in the script or in this table.

### Test the Playwright automation

1. **Build the deployable zips first.** The scripts upload the files referenced
   in `.env`:
   ```powershell
   cd ..
   .\gradlew.bat buildClientExtensions --no-daemon --offline
   ```
2. **Ensure Liferay is running** at the `LIFERAY_BASE_URL` configured in `.env`.
3. **Run the fragment import.** In headless mode it completes silently; with
   `PLAYWRIGHT_HEADLESS=false`, confirm:
   - Login succeeds (no redirect back to `/c/portal/login`)
   - Fragments portlet loads
   - `QC Website Sections` collection actions menu opens
   - Import dialog receives the zip and shows a result
4. **Run the master page import** and confirm:
   - Page Templates → Masters tab opens
   - Options menu → Import dialog appears
   - `qc-master.zip` uploads and reports success
5. **Verify in Liferay:**
   - **Design → Fragments** → collection shows the fragments
   - **Design → Page Templates → Masters** → `QC Master` is present and published
   - Assign a page to `QC Master` and preview in English and Arabic
6. **If a script fails:**
   - Read the terminal error
   - Check the screenshot saved as `automation/import-fragments-error.png` or
     `automation/import-master-error.png`
   - Common fixes: wrong credentials, Liferay not running, selectors changed
     between Liferay versions, or the zip path in `.env` is incorrect.

See `automation/README.md` for details.

## Related skills

- `qatar-chamber-header-footer-master` — build the header/footer/master page
  content and data contracts.
- `qatar-chamber-style-book` — import the QC Style Book that supplies the
  design tokens consumed by these fragments.
- `liferay-headless-skill` — seed and update the NavItem/FooterLink objects via
  the Liferay headless API.
