---
name: caveman-install-skill
description: Install, verify, and use the "caveman" Claude Code plugin (JuliusBrussee/caveman) — ultra-compressed terse response mode. Use when user asks how to install caveman, set up caveman mode, or use caveman commands/levels.
---

# Caveman Install Skill

## Install

1. Add marketplace:
```
/plugin marketplace add JuliusBrussee/caveman
```

2. Install plugin:
```
/plugin install caveman@caveman
```

3. Restart Claude Code session (or start new one) — `SessionStart` hook auto-activates default level (`full`).

## Verify

- Check marketplace registered: `C:\Users\bataw\.claude\plugins\known_marketplaces.json` — key `caveman`, repo `JuliusBrussee/caveman`.
- Check plugin installed: `C:\Users\bataw\.claude\plugins\installed_plugins.json` — key `caveman@caveman`.
- Session start banner shows: `CAVEMAN MODE ACTIVE — level: full`.

## Optional: statusline badge

Plugin ships statusline script but doesn't wire it automatically. Add to `C:\Users\bataw\.claude\settings.json`:
```json
"statusLine": {
  "type": "command",
  "command": "powershell -ExecutionPolicy Bypass -File \"C:\\Users\\bataw\\.claude\\plugins\\cache\\caveman\\caveman\\<version-hash>\\src\\hooks\\caveman-statusline.ps1\""
}
```
Replace `<version-hash>` with actual folder under `plugins\cache\caveman\caveman\` (check `installed_plugins.json` → `version` field).

## Usage

- Toggle level: `/caveman lite|full|ultra|wenyan-lite|wenyan-full|wenyan-ultra`
- Turn off: say "stop caveman" or "normal mode"
- Default level on activate: `full`
- Levels drop progressively more (articles/filler → heavier compression at ultra/wenyan)
- Code, commits, PRs, security warnings, irreversible-action confirms: always written normal, never compressed
- `/caveman-help` — quick reference card of all modes/commands
- `/caveman-stats` — real token usage + savings for current session (reads session log directly)
- `/caveman-commit` — generate terse Conventional-Commits style commit message
- `/caveman-review` — one-line-per-finding terse code review comments
- `/caveman-compress <filepath>` — compress a memory/CLAUDE.md-style file in place, keeps human-readable backup as `FILE.original.md`
- `/caveman-init` — drop always-on caveman activation rule into current repo (for every IDE agent, not just this session)
- Subagents (`cavecrew`): `cavecrew-investigator` (read-only code locator), `cavecrew-builder` (surgical 1-2 file edit), `cavecrew-reviewer` (diff/PR reviewer) — all return caveman-compressed output to save main-thread context. Use `/cavecrew` skill for guidance on when to delegate to them.

## Persistence

Mode persists every response, no revert after many turns, survives long sessions. Only exits on explicit "stop caveman"/"normal mode" or session end.
