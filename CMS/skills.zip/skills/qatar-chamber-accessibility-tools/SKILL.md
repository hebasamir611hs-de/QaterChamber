---
name: qatar-chamber-accessibility-tools
description: Build and deploy the Qatar Chamber Accessibility Tools panel (QC-GBL-003,
  story 129364) — a site-wide globalCSS/globalJS Client Extension for High Contrast,
  Zoom In/Out, and Reset, wired to the qc-global-site-header fragment's accessibility
  icon and to an admin-controlled Liferay Object toggle. Encodes the exact
  client-extension.yaml properties Liferay DXP (2026.Q1.9+) actually requires for
  a globalCSS/globalJS extension to inject site-wide (scope, scriptLocation) and
  the silent-failure gotcha with scriptElementAttributes. Use when creating,
  updating, or debugging the QC accessibility panel or any other site-wide
  (non-fragment) client extension.
---

# Qatar Chamber Accessibility Tools

Builds the **T14** deliverable from the sprint plan (QC-GBL-003, story 129364):
an accessibility panel — High Contrast toggle, Zoom In/Out, Reset — deployed as
a site-wide `client-extensions/qc-accessibility-tools` (globalCSS + globalJS),
wired to the header icon built in **T15** (`qc-global-site-header` fragment).

Architecture is **client-extension + fragment + Object** — same "no WAR theme"
pattern as the rest of QC frontend. See `qatar-chamber-header-footer-master`
for the header fragment itself and `qatar-chamber-style-book` for the
`--qc-*` CSS variables this panel's styling depends on.

> **This is the third `qc-*` global client extension** alongside `qc-frontend`
> (global CSS/JS/favicon) and `qc-i18n-utils` (global JS). All three share the
> exact same YAML gotchas below — if you're touching any of them, read this
> whole skill, not just the accessibility-specific parts.

## Canonical facts (this project)
- Liferay: DXP quarterly LTS (verified 2026.Q1.9), http://localhost:8080, admin
  `test@liferay.com` / `test`.
- Qatar Chamber site groupId `37246` (env-specific), ERC `QCDEMO-SITE-qatar-chamber`.
- Repo source of truth: `client-extensions/qc-accessibility-tools/`
  (`client-extension.yaml`, `assets/qc-accessibility.css`, `assets/qc-accessibility.js`).
- Admin toggle: **accessibilityHeaderConfiguration** Object (ERC
  `QCDEMO-129364-accessibility-header-configuration`), one boolean field
  `accessibilityToolsEnabled`. Headless: `GET /o/c/accessibilityheaderconfigurations/scopes/{groupId}?pageSize=1`.
  Grant **Guest: View** on this Object or anonymous visitors just don't see the
  icon (fails closed, not an error).
- Header integration lives in `qc-global-site-header`'s `main.js`/`index.html`
  (see `qatar-chamber-header-footer-master`), NOT in this client extension:
  the header owns the icon + its visibility; this CX only owns the panel and
  reacts to a `document`-level `qc:accessibility:toggle` CustomEvent the header
  dispatches on click. Keeps the two independently deployable.

## Feature spec (from the story / sprint plan T14, T18)
- **High Contrast**: toggles a `qc-a11y-contrast` class on `<html>`; CSS forces
  black bg / white text / high-contrast focus color. Browsers without CSS
  custom-property support just drop the `var()` rules and keep the default
  theme — no JS feature-detection needed, that's the "graceful fallback" the
  story asks for.
- **Zoom In/Out**: increments/decrements a `--qc-a11y-zoom-scale` CSS variable
  on `<html>` in steps of 0.1, clamped `[0.8, 1.4]`; `html { font-size: calc(100% * var(--qc-a11y-zoom-scale, 1)) }`
  scales the whole page, no reload.
- **Reset**: clears both to default and drops the sessionStorage keys.
- **Session persistence (not localStorage)**: `sessionStorage` keys
  `qcA11yContrast` / `qcA11yZoomStep`, applied on every page load *before* the
  panel DOM is even built, so the effect is instant across navigation within
  one browser session (AC-7 — explicitly NOT persisted across sessions).
- **Keyboard nav**: panel controls are real `<button>` elements; Escape closes;
  focus moves to the close button on open.
- **Negative scenario**: the `qc:accessibility:toggle` handler wraps panel
  open/close in try/catch so a bug here can never break the header icon —
  they're separate DOM subtrees in separate deployables by construction.
- **T18 smoke test** (manual, dev-led): open a page, click the icon, click
  each control, reload the page mid-session and confirm settings held, tab
  through the panel with keyboard only. Full WCAG 2.1 AA audit is explicitly
  **deferred** to a post-sprint hardening pass — don't scope-creep into it here.

## THE CLIENT-EXTENSION.YAML FORMAT (get this exactly right)

This is the part that silently fails with **zero errors anywhere** (not in
`bundles/logs/liferay.*.log`, not in the OSGi console) if you get it wrong.
`blade gw deploy` succeeds, the bundle shows `Active`, the CETConfiguration
shows `ACTIVE` in `scr:list` — and the asset still never appears on a page.

```yaml
assemble:
    - from: assets
      into: static
qc-accessibility-css:
    name: QC Accessibility Tools CSS
    scope: company
    type: globalCSS
    url: qc-accessibility.css
qc-accessibility-js:
    name: QC Accessibility Tools Panel
    scope: company
    scriptElementAttributes:
        defer: true
    scriptLocation: head
    type: globalJS
    url: qc-accessibility.js
```

Three rules, all required, all silent if skipped:

1. **`scope: company` is mandatory.** Default scope for `globalCSS`/`globalJS`
   is `layout` — the extension only activates if an admin manually drags it
   onto a page like a widget (Page Settings → Client Extensions). Nothing
   ever does that for a site-wide panel, so without this line the extension
   just never runs, forever, with the bundle sitting there `Active` and
   looking fine. (Available since DXP 2025.Q1 / 2024.Q4.8 for JS — this
   workspace is 2026.Q1.9, always fine here.)
2. **`scriptLocation: head` must be explicit for `globalJS`.** Liferay Learn's
   own YAML reference documents `head` as the default — in practice, omitting
   it drops the `<script>` tag silently. Always write it out.
3. **Never redeclare `data-senna-track` in `scriptElementAttributes`.**
   Liferay's own CET script renderer sets this attribute itself. Redeclaring
   it collides and the *entire* `<script>` tag is dropped — looks exactly
   like a broken extension, not an attribute problem, and there is no log
   line anywhere pointing at it. Custom attributes the framework doesn't
   manage (`defer`, `data-gtm-container-id`, etc.) are safe to declare.

`themeFavicon` type extensions (e.g. `qc-favicon` in `qc-frontend`) don't need
`scope` — favicon is inherently company-wide.

## Deploy

No `build.gradle` needed — client extensions under `client-extensions/` are
auto-detected by the workspace. Deploy just this one (faster than a full
`blade gw deploy`):

```
blade gw :client-extensions:qc-accessibility-tools:deploy
```

Confirm the OSGi bundle picked up the new zip:
```
blade sh 'lb' | grep -i qcaccessibilitytools     # should show Active
```

## Verify (don't trust one page — check two)

Company-scope injection can look inconsistent across page types while it's
actually just fine; always cross-check a normal site page against Control
Panel before concluding something's broken:

```bash
curl -s "http://localhost:8080/web/<site>/<page>?x=$(date +%s)" | grep -o 'qc-accessibility\.\(css\|js\)'
curl -s -u test@liferay.com:test "http://localhost:8080/group/control_panel/manage/-/asset_publisher/scope/<groupId>" | grep -o 'qc-accessibility\.\(css\|js\)'
```

Both should print the filename. If neither does, check `scope: company` is
present and redeploy. If it prints in Control Panel but not on the site page,
just re-curl with a fresh cache-buster — that combination has been a stale
fetch, not a real bug, every time it's shown up here.

Deeper diagnosis, if the above isn't enough: `blade sh 'scr:list'`, find
`com.liferay.client.extension.type.internal.configuration.CETConfigurationFactory`
(bundle `com.liferay.client.extension.type.impl`) and confirm your PID shows
`ACTIVE`. If it's active but nothing renders, diff the actual built config —
`unzip -p bundles/osgi/client-extensions/qc-accessibility-tools.zip qc-accessibility-tools.client-extension-config.json`
— against a known-good sample
(`liferay/liferay-portal` → `workspaces/liferay-sample-workspace/client-extensions/liferay-sample-global-js-3/client-extension.yaml`)
to spot a stray property.

## Header wiring (lives in the OTHER skill/fragment, not here)

The `qc-global-site-header` fragment's `main.js` fetches the Object and
dispatches the shared event — this CX never touches the icon:

```js
qcFetch('/o/c/accessibilityheaderconfigurations/scopes/' + groupId() + '?pageSize=1')
  .then(function (data) {
    var config = (data.items || [])[0];
    if (!config || config.accessibilityToolsEnabled !== false) {
      accessibilityBtn.hidden = false;
    }
  });

accessibilityBtn.addEventListener('click', function () {
  document.dispatchEvent(new CustomEvent('qc:accessibility:toggle'));
});
```

Pushing a fragment change like this live uses JSONWS `update-fragment-entry`
(13-param overload) + `blade sh` Gogo `updateLatestChanges` per-`FragmentEntryLink`
— see `fragment-update-propagation-workflow` memory / `qatar-chamber-header-footer-master`
skill; do not re-derive that mechanism here.

## Troubleshooting (every failure hit on this project)
| Symptom | Cause | Fix |
|---|---|---|
| Bundle `Active`, CETConfiguration `ACTIVE`, asset still never appears on any page | `scope` defaulted to `layout` | add `scope: company` to the entry |
| CSS injects fine, JS never does, no errors logged | `scriptLocation` omitted (docs say default `head`, doesn't behave as one in practice) | add `scriptLocation: head` explicitly |
| One globalJS entry works, another in the same or a sibling CX doesn't, configs otherwise identical | a `scriptElementAttributes` key duplicates one Liferay sets itself (`data-senna-track`) | remove the duplicate key; framework's own default value is fine |
| Asset shows in Control Panel fetch but not a public site page fetch (or vice versa) | stale/cached curl, not a real gap | re-curl with a fresh cache-busting query param |
| `clientextensionentry` DB table has 0 rows even for extensions that work fine | expected for `scope: company` — that table is for per-page (`layout`-scope) assignments, not a health signal | ignore it; verify via rendered HTML instead |
