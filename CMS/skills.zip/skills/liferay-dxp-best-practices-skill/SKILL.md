---
name: liferay-dxp-best-practices-skill
description: Modern Liferay DXP (quarterly LTS line, incl. 2026.Q1) implementation
  guidance applied whenever a backlog item / user story is analyzed, planned, or
  executed. Loaded by the analyzer, the orchestrator (Steps 4/4b), the structure
  and article executors, and the reporter.
---

# Liferay DXP Modern Best Practices

## Verification duty (read first)
This skill encodes durable practices of the quarterly-release DXP era. Exact
behavior of the pinned point release (e.g. 2026.Q1.9) MUST be confirmed
against its official release notes and the current property/feature-flag
reference by the administrator at install/upgrade time. When this skill and
the release notes disagree, the release notes win — and this file gets updated.

## Release & upgrade posture
- Pin the exact quarterly LTS version per environment; upgrade deliberately,
  never by floating "latest".
- Review feature flags on every upgrade: dev/beta flags must never reach
  production. feature.flag.LPD-63311 (MCP) is required by this pipeline —
  verify per release whether it has been promoted to default-on and prune
  the property when it has (then re-baseline hashes per Guide §2.11).
- After every upgrade: re-run the full fixture suite (Part 12) before
  touching the real backlog; audit portal-ext against the current property
  reference and delete dead properties.

## Objects vs Web Content structures (decision rubric for the analyzer)
Prefer **Liferay Objects** when the story describes data-like entities:
records that applications CRUD, entries needing per-entry permissions,
workflow/approval states, relationships between entities, or headless
consumption by external systems (Objects auto-generate /o/c/{name} REST
APIs and are ERC-native). Concretely, apply the rubric PER ENTITY, not to
the whole story: an entity is an Objects candidate when it exhibits at
least one of — a self-referencing/parent-child field, an explicit ordering
field, a soft active/inactive status flag, or a draft/submit/publish/
update/unpublish-style workflow gated by per-action permissions. A flat
record with only display fields (labels, images, URLs) stays a Structure
even in a story where a sibling entity qualifies as an Objects candidate
(e.g. a "Header Logo" record next to a "Navigation Item" record — only the
latter typically qualifies).
Prefer **Journal (Web Content) structures** — this pipeline's default
deliverable — when the entity describes page-rendered editorial content:
templated display, localized publishing, listing/detail pages, or simply
has none of the Objects signals above.
Rule for this pipeline (updated — see liferay-headless-skill "Endpoints",
Object Definition verified working 2026-07-05): the analyzer sets
objectsCandidate=true on each individual entity the rubric matches (and
rolls this up to a whole-analysis objectsCandidate=true if any entity
qualifies). Step 4 plan derivation sets that entity's
structure.json.provisionAs="object" automatically — this is a per-entity
plan-derivation decision, not a blanket whole-story switch, and it does NOT
bypass the existing risk/confidence HITL gate (objectsCandidate=true still
floors risk at "medium" and must be stated in reasoning, so a human sees it
before/at the same gate as today). Never invent Objects-candidate signals
that aren't grounded in the story's acceptance criteria.

## Page & template strategy
- Modern DXP favors Display Page Templates mapped to a structure for detail
  views, and collection pages / collection providers for listings, over
  legacy FTL widget templates.
- This pipeline's automated deliverable remains FTL DDM templates (stable,
  headless-creatable). The reporter MUST note the DPT/collection alternative
  in its summary so editors can adopt it manually.
- Never generate legacy widget pages for new listing/detail requirements.

## Headless & ERC discipline
- ERC-first everywhere (already mandatory in this system). Never store or
  emit internal database IDs in plans, references, or content bodies.
- Stories with intent=migrate or bulk language ("import", "bulk load",
  "hundreds of records") MUST route through the headless batch engine —
  never a loop of individual PUTs. The current pipeline does not implement
  batch; therefore migrate intent stays HITL-gated and the reasoning must
  say "requires batch engine implementation".

## Localization & RTL
- The "(AR)" fallback markers map 1:1 to untranslated units in an XLIFF
  export; use Liferay's XLIFF export/import for translator handoff rather
  than editing content inline.
- Templates and fragments must render correctly under dir="rtl": use logical
  CSS properties (margin-inline-start, not margin-left) in any generated FTL.
- Validate locale-correct date and numeral formatting for ar_SA in detail
  templates.

## Search
- Elasticsearch sidecar is development-only; production requires a remote
  Elasticsearch cluster.
- After creating or altering a structure, verify affected content is
  indexed; schedule full reindexes off-hours for large volumes.

## Permissions & security
- Production pipeline writes use a dedicated, least-privilege service
  account with scoped roles — never the Administrator account (Guide
  Part 15). Prefer site-scoped roles over instance-scoped.

## Publications
- In production, content changes should flow through Publications
  (changeset review/publish), not direct writes to live. Out of scope for
  the localhost demo; if the target instance has Publications enabled, the
  run must target a publication and the report must record which one.

## Media & documents
- Never embed base64 images in content bodies; use the document library
  (folder references by ERC) and rely on Adaptive Media for renditions.

## Anti-patterns (reject in plans, flag in reviews)
- POST to non-ERC endpoints; blind creates of any kind.
- Hardcoded internal IDs, group IDs, or folder IDs in plans or content.
- Disabling auth verifiers outside localhost (the demo portal-ext does this
  deliberately — Part 15 reverses it before any exposure).
- Custom OSGi modules where a Client Extension suffices.
- Direct database writes to Liferay tables, ever.