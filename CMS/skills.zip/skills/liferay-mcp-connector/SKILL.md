---
name: liferay-mcp-connector
description: Configures and connects a Liferay Model Context Protocol (MCP) server to Claude Code. Use this skill when the user wants to set up, configure, or troubleshoot a Liferay MCP connection, generate the Base64 Authorization header, enable the MCP feature flag, or create/edit the .mcp.json file for a Liferay instance. developed by Alaa Medhat
---

# Liferay MCP Connector Setup

## Overview
This skill configures Claude Code to connect to a Liferay MCP server using the
`mcp-remote` npx bridge. Follow the steps in order. Gather the required inputs
from the user before writing any files.

## Required Inputs
Ask the user for these if not already provided:
1. **Liferay bundle path** (e.g., `D:\liferay\bundles` or `~/liferay/bundles`)
2. **Liferay HTTP port** (default `8080`; confirm if custom, e.g. `9595`)
3. **Credentials** as `email:password` (e.g., `admin@liferay.com:password`)
4. **Liferay version** (to determine whether the feature flag is needed)
5. **Project root** where `.mcp.json` should live

## Step 1: Enable the Liferay MCP Feature Flag
For Liferay **2025.Q4 and later**, the MCP server is behind a feature flag.

1. Open `<bundle-path>/portal-ext.properties` (create it if missing).
2. Add:
   ```properties
   ## Enable Liferay MCP Server (2025.Q4+)
   feature.flag.LPD-63311=true
   ```
3. Tell the user to **restart Liferay** after this change.

## Step 2: Verify the Tomcat Port
1. Open `<bundle-path>/tomcat/conf/server.xml`.
2. Find the HTTP `<Connector>` tag and read its `port` attribute:
   ```xml
   <Connector maxThreads="75" port="9595" protocol="HTTP/1.1"
              connectionTimeout="20000" redirectPort="8443"
              maxParameterCount="1000" />
   ```
3. Use that port in the MCP URL below. Default is `8080`.

## Step 3: Generate the Base64 Authorization Header
The header value is Base64 of `email:password`. Run the command matching the
user's OS, replacing the credentials with the real ones.

**Windows (PowerShell)** — note `base64` is NOT a valid command on Windows:
```powershell
[Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("admin@liferay.com:password"))
```

**macOS / Linux (Bash)** — use `-n` to avoid encoding a trailing newline:
```bash
echo -n "admin@liferay.com:password" | base64
```

Capture the resulting string for the next step.

## Step 4: Write .mcp.json
Create or update `.mcp.json` in the project root. Substitute the real port and
the Base64 string from Step 3.

```json
{
  "mcpServers": {
    "liferay": {
      "command": "npx",
      "args": [
        "mcp-remote",
        "http://localhost:9595/o/mcp",
        "--header",
        "Authorization: Basic <BASE64_STRING_HERE>"
      ]
    }
  }
}
```

Notes:
- Prefer `mcp-remote` over a native `"type": "sse"` config for reliability.
- Keep exactly one space after `Basic`.
- If credentials change, regenerate the Base64 string (Step 3) and update here.

## Step 5: Connect and Verify
1. Ensure Liferay is fully started.
2. In Claude Code, run `/mcp`.
3. Expect `liferay • connected` with tools loaded.

## Troubleshooting
- **`base64` not recognized (Windows):** use the PowerShell `[Convert]` command.
- **Connection refused:** confirm the port matches `server.xml` and Liferay is up.
- **401 Unauthorized:** re-generate the header; verify the `email:password`
  format and that there is no trailing newline (use `echo -n`).
- **Tools not appearing / flag ignored:** confirm `feature.flag.LPD-63311=true`
  is in `portal-ext.properties` and Liferay was restarted.
- **npx errors:** ensure Node.js/npx is installed and on PATH.

## Security
Never commit real credentials. Treat the Base64 header as a secret; it is
trivially reversible (encoding, not encryption).