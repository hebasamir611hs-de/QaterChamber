---
name: qatar-chamber-style-book
description: Create, package, and import the Qatar Chamber "QC Style Book" into
  Liferay DXP (quarterly LTS, e.g. 2026.Q1.9) using the exact style-book import
  format that this version requires. Encodes the brand palette, the two-file zip
  layout, the correct themeId, DB verification, and every failure mode we hit so
  the import succeeds first time.
---

# Qatar Chamber Style Book

Creates the **QC Style Book** — the Qatar Chamber brand frontend-token set
(maroon `#911731` / bronze `#a66f43`) — and imports it into a Liferay site's
**Design → Style Books**.

> **Downstream consumers:** the tokens defined here (e.g. `--primary`,
> `--font-family-base`) are consumed by the QC header/footer fragments and the
> `QC Master` page template. When building or updating those, use the
> **`qatar-chamber-header-footer-master`** skill — its fragments reference these
> Style Book variables (never hex literals) so re-theming happens from one place.

## Canonical facts (this project)
- Liferay: DXP quarterly LTS (verified on 2026.Q1.9). Base URL http://localhost:8080.
- Qatar Chamber site: friendlyURL `/qatar-chamber`, groupId `37246` (env-specific).
- Site theme id: **`classic_WAR_classictheme`** (NOT bare `classic`). Confirm per
  env: `SELECT DISTINCT themeId FROM LayoutSet WHERE groupId=<siteGroupId>;`
- Style book name: `QC Style Book`, styleBookEntryKey `qc-style-book`.
- Source of truth in repo:
  `build-resources/style-books/qc-style-book/` (the two source files) and
  `build-resources/style-books/qc-style-book.zip` (the import artifact).

## THE IMPORT FORMAT (get this exactly right)
Liferay's `StyleBookEntryZipProcessorImpl` expects a **two-file** layout inside a
zip. It does NOT accept inline token values.

```
qc-style-book/style-book.json
qc-style-book/frontend-tokens-values.json
```

`qc-style-book/style-book.json` (metadata only):
```json
{
	"frontendTokensValuesPath": "frontend-tokens-values.json",
	"name": "QC Style Book",
	"themeId": "classic_WAR_classictheme"
}
```
- `frontendTokensValuesPath` is a **filename RELATIVE to the style book folder**
  (`frontend-tokens-values.json`). Do NOT prefix it with `qc-style-book/` — the
  importer resolves it inside the folder, so a prefixed path is not found and the
  tokens silently import as empty (`[]`).
- `themeId` MUST equal the site's real theme id (`classic_WAR_classictheme`).
  Using bare `classic` still imports but raises the "style book is based on a
  theme different from the site's default theme" warning and can mis-bind tokens.
- Optional keys the importer also reads: `defaultStyleBookEntry` (bool),
  `thumbnailPath`. Omit unless needed; Liferay's own export omits them.

`qc-style-book/frontend-tokens-values.json` (the actual values):
a JSON object keyed by token name, each `{ cssVariableMapping, value }`, matching
the theme's frontend-token-definition. Example entries:
```json
{
	"primaryColor":   { "cssVariableMapping": "primary",       "value": "#911731" },
	"secondaryColor": { "cssVariableMapping": "secondary",     "value": "#a66f43" },
	"brandColor1":    { "cssVariableMapping": "brand-color-1", "value": "#911731" }
}
```

## Brand palette (QC token values)
Colors:
- primary / brand-color-1 / btn-link-color / all btn*Primary* = **#911731**
  (hover `#7a132a`)
- secondary / brand-color-2 / all btn*Secondary* = **#a66f43** (hover `#8f5f3a`)
- brand-color-3 / black / body-color / gray-900 = **#1d1d1b**
- brand-color-4 = **#f6f0ec**; light = `#f6f6f6`; body-bg / white = `#ffffff`
- grays 100..900: #ededed, #dededd, #d0d0d0, #a8a8a7, #7c7b7b, #6c6c6b, #4a4a49,
  #343432, #1d1d1b; text-muted `#6c6c6b`
Typography/other:
- font-family-base / font-family-sans-serif = `var(--qc-font-family-base)`
  (supplied by the `qc-frontend` client extension's global CSS)
- font-size base/lg/sm = 1 / 1.125 / 0.875 rem; weights normal/semi/bold = 400/600/700
- h1..h6 = 2.25, 1.875, 1.5, 1.25, 1.125, 1 rem
- border-radius / lg / sm = 0.5 / 0.625 / 0.375 rem

The complete, authoritative token file lives at
`build-resources/style-books/qc-style-book/frontend-tokens-values.json`
(~60 tokens; all names exist in the Classic theme's 142-token
`frontend-token-definition.json`, so `themeId=classic_WAR_classictheme` is valid).

## Verify token names against the theme (optional)
Classic theme definition is inside the deployed war:
`bundles/osgi/portal-war/classic-theme.war` -> `WEB-INF/frontend-token-definition.json`.
Every token used here must appear there or it is dropped on import.

## Build the import zip (Windows PowerShell)
Use forward-slash zip entries (Java/Liferay require `/`, not `\`).
```powershell
$dir='<repo>\build-resources\style-books\qc-style-book'
$zip='<repo>\build-resources\style-books\qc-style-book.zip'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
if (Test-Path $zip) { Remove-Item $zip -Force }
$fs=[System.IO.File]::Open($zip,[System.IO.FileMode]::Create)
$archive=New-Object System.IO.Compression.ZipArchive($fs,[System.IO.Compression.ZipArchiveMode]::Create)
foreach ($name in @('style-book.json','frontend-tokens-values.json')) {
  $entry=$archive.CreateEntry("qc-style-book/$name",[System.IO.Compression.CompressionLevel]::Optimal)
  $w=New-Object System.IO.StreamWriter($entry.Open())
  $w.Write([System.IO.File]::ReadAllText((Join-Path $dir $name)))
  $w.Flush(); $w.Dispose()
}
$archive.Dispose(); $fs.Dispose()
```
Note: `[System.IO.Compression.ZipFile]::CreateFromDirectory` on Windows writes
backslash entry names — avoid it; use the explicit `CreateEntry` loop above.

## Import (UI)
1. Go to the **Qatar Chamber** site (URL `/group/qatar-chamber/...`) →
   **Design → Style Books**.
2. **Import** (top-right menu / icon) → **Choose File** → `qc-style-book.zip`.
3. Keep **Overwrite Existing Style Books** checked (idempotent re-import).
4. **Import** → expect "The files were imported correctly." A theme-mismatch
   warning means `themeId` != site theme; fix `themeId` and re-import.
5. The card shows **APPROVED** and **Based on Classic Theme**.

## Verify the import (DB — proof it actually stored values)
```sql
SELECT styleBookEntryId, groupId, name, themeId, head,
       LENGTH(frontendTokensValues) AS ftvLen
FROM StyleBookEntry WHERE name='QC Style Book';
```
`ftvLen > 0` (≈11k) = success. `ftvLen = 0` (or the column literally `[]`) =
tokens were dropped -> the format is wrong (see Troubleshooting).
MySQL creds: schema `qatarchamberdev`, user `qatarchamberdev`, password in
`bundles/portal-ext.properties` (`jdbc.default.password`). Never echo the password.

## Apply / activate
- An imported style book that stored values imports as **APPROVED** and selectable.
  (An INACTIVE badge means empty token values — a broken import, not a workflow
  state; StyleBookEntry has no status column.)
- Set site default: Style Books → the card's **⋮ → Mark as Default**, or via Site
  Settings.
- Per page/template: Page Editor → right sidebar **Page Design Options (brush)** →
  **Style Book** → select **QC Style Book**.

## Troubleshooting (every failure we actually hit, in order)
| Symptom | Cause | Fix |
|---|---|---|
| Import error: `property "themeId" is missing` | style-book.json had no `themeId` | add `themeId` |
| Card shows **INACTIVE**, kebab only has Export/Delete, no Edit/Publish | `frontendTokensValues` stored empty (`[]`) — nothing to edit | fix token format below and re-import |
| DB `ftvLen=0` after import, values were inline | importer ignores inline `frontendTokensValues`; needs `frontendTokensValuesPath` + separate file | split into two-file layout |
| DB `ftvLen=0` with two files present | `frontendTokensValuesPath` was folder-prefixed (`qc-style-book/...`) | use a **relative filename** only |
| Warning: "based on a theme different from the site's default theme" | `themeId` was bare `classic` | set `themeId=classic_WAR_classictheme` (match `LayoutSet.themeId`) |
| Zip entries show backslashes / import can't read | built with `CreateFromDirectory` on Windows | build with explicit `CreateEntry` + `qc-style-book/<file>` |

## Ground-truth trick
If the format ever changes, create/import an empty style book via **New**, then
**⋮ → Export** it. The exported zip reveals the exact current layout and the
`frontendTokensValuesPath` convention Liferay expects — mirror it.
