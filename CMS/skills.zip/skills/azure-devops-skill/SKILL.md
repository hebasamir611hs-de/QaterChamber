---
name: azure-devops-skill
description: Reading Product Backlog Items from the Qatar Chamber project via the
  official @azure-devops MCP, normalizing HTML, splitting acceptance criteria
  with stable ids, driving tag-based HITL approvals, and posting run reports.
---

# Azure DevOps Skill

## Connection
- Org: ihorizons (https://dev.azure.com/ihorizons)
- Project: 'Qatar Chamber Website Revamp' — confirmed state=wellFormed,
  process template=Scrum (so backlog items are 'Product Backlog Item').
- Auth: az login (Entra). Windows az.cmd full path:
  & "C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd" login
  (Signed in as Alaa.Medhat@ihorizons.com, tenant iHorizons. Use the full
  az.cmd path on Windows — bash shells often can't find bare `az`.)
- MCP: official @azure-devops/mcp via npx (registered as
  `npx -y @azure-devops/mcp ihorizons`). No PAT, no local clone. The MCP
  server authenticates with the az login token via the Node API — it does
  NOT depend on the `az devops` CLI extension.
- CLI defaults (set once so `az devops`/`az boards` commands are scoped):
  az devops configure --defaults \
    organization=https://dev.azure.com/ihorizons \
    "project=Qatar Chamber Website Revamp"

## ALWAYS pass the project (no interactive prompts)
Every @azure-devops MCP tool call MUST include the project argument
`project: 'Qatar Chamber Website Revamp'` (equivalently the `project` /
`projectNameOrId` field the tool exposes). If it is omitted, the server raises
an interactive elicitation ("MCP server azure-devops requests your input —
Select the Azure DevOps project…") that blocks unattended/agentic runs.
This applies to every tool, including but not limited to: wit_get_work_item,
wit_update_work_item, wit_add_work_item_comment, wit_get_work_item_comments,
wit_run_query / WIQL execution, wit_add_work_item_attachment, and any
work-item relation/tag update. Never rely on a server default; pass it
explicitly on each call.

## Reading work items
- Type is ALWAYS 'Product Backlog Item'. Querying 'User Story' returns zero rows
  and looks like an auth failure.
- Current sprint WIQL (use @currentIteration to avoid team-selection prompts):
  SELECT [System.Id], [System.Title], [System.Description],
         [Microsoft.VSTS.Common.AcceptanceCriteria], [System.Tags]
  FROM WorkItems
  WHERE [System.WorkItemType] = 'Product Backlog Item'
    AND [System.IterationPath] = @currentIteration

## HTML -> Markdown normalization (apply to Description and AC)
1. Strip <script>, <style>.
2. <p>, <br> -> newlines.
3. <ul>/<ol>/<li> -> "-" / "1." items.
4. <strong>/<b> -> **...**.
5. <a href> -> [text](href).
6. Collapse multiple blank lines.

## Acceptance-criteria splitting (in priority order)
1. Gherkin lines (Given/When/Then/And).
2. Numbered lists.
3. Bullets.
4. Lines starting "Rule:" or "AC:".
Output per item: { "id": "AC-1", "text": "...", "type": "given|when|then|rule" }
Assign stable ids AC-1..AC-n in document order; ids are immutable for the
life of the run and are referenced by analysis entities and plan derivedFrom.

## HITL over the work item
- Request approval: add tag 'agentic-hold' + post a System.History comment with
  runId, intent, risk, confidence, hard signals, and the two decision tags.
- Read a decision: GET the PBI, inspect System.Tags for
  'agentic-approved' or 'agentic-rejected'.

## Reporting
- Post the run summary as a System.History comment.
- Attach state-{runId}.json via the attachments API and link it as an
  AttachedFile relation.
- Never include credentials or raw auth headers in any comment.

## Troubleshooting

### MCP: "requests your input — Select the Azure DevOps project"
The tool was called without a project. Re-issue the call with
`project: 'Qatar Chamber Website Revamp'`. See "ALWAYS pass the project" above.
This does NOT affect the MCP server itself; it only means a required argument
was missing on that call.

### WIQL returns zero rows
You almost certainly queried 'User Story'. This is a Scrum project — use
'Product Backlog Item'.

### `az devops` CLI throws `[WinError 5] Access is denied` on
`...\.azure\cliextensions\azure-devops\azure_devops-1.0.5.dist-info`
Root cause: the extension was installed by an ELEVATED process, leaving files
whose ACLs block the normal user (broken inheritance). The MCP server is
unaffected (it uses the az login token via the Node API), but every
`az devops` / `az boards` CLI command fails until the ACLs are repaired.

Fix — run from an ELEVATED PowerShell (UAC), then reset ACLs so the normal
user regains access:
```powershell
$ext = "$env:USERPROFILE\.azure\cliextensions\azure-devops"
$az  = "C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd"
takeown /f "$ext" /a /r /d Y
icacls  "$ext" /grant "*S-1-5-32-544:(OI)(CI)F" /t /c   # Administrators
Remove-Item -LiteralPath "$ext" -Recurse -Force
& $az extension add --name azure-devops
icacls  "$ext" /reset /t /c                              # re-inherit -> user gets Full
```
IMPORTANT: reinstalling the extension while elevated re-breaks it. ALWAYS run
`icacls "$ext" /reset /t /c` after the reinstall (or install non-elevated) so
the freshly written files inherit the parent ACL that grants the normal user
Full control. Verify from a NON-elevated shell:
`& $az devops configure --list` should print the defaults with no traceback.