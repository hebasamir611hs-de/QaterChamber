#!/usr/bin/env bash
# Prerequisite installer for the Azure DevOps MCP server (macOS / Linux).
# Organization: ihorizons | Scoped project: Qatar Chamber Website Revamp (Scrum template)
# Auth options: [1] Azure CLI (recommended)  [2] PAT (optional fallback)
set -euo pipefail

ORG="ihorizons"
PROJECT="Qatar Chamber Website Revamp"

echo "==> Azure DevOps MCP setup for org '$ORG' (project: $PROJECT)"
echo "    NOTE: this project uses the Scrum template -> backlog items are"
echo "          typed 'Product Backlog Item' (NOT 'User Story')."
echo ""

echo "==> Checking Node.js..."
if command -v node >/dev/null 2>&1; then
  echo "    Found $(node --version)"
else
  echo "    Installing Node.js..."
  if [[ "$OSTYPE" == "darwin"* ]]; then
    brew install node
  else
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt-get install -y nodejs
  fi
fi

echo ""
echo "==> Choose how Claude will authenticate to Azure DevOps:"
echo "  [1] Azure CLI  (recommended; opens a browser, no secret stored)"
echo "  [2] PAT        (optional fallback; token stored in plaintext, can scope to one project)"
read -r -p "Enter 1 or 2: " authChoice

case "$authChoice" in
  1)
    echo -e "\n==> Checking Azure CLI..."
    if command -v az >/dev/null 2>&1; then
      echo "    Azure CLI already installed ($(az version --query '\"azure-cli\"' -o tsv 2>/dev/null || echo 'version unknown'))."
    else
      echo "    Installing Azure CLI..."
      if [[ "$OSTYPE" == "darwin"* ]]; then
        brew install azure-cli
      else
        curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash
      fi
    fi

    read -r -p "Run 'az login' now (opens a browser)? [y/N]: " doLogin
    if [[ "$doLogin" =~ ^[Yy]$ ]]; then
      az login
      echo -e "\n    Ensuring the Azure DevOps CLI extension is present..."
      az extension add --name azure-devops 2>/dev/null || true
      echo "    Verifying org access..."
      az devops project list --organization "https://dev.azure.com/$ORG" --output table || \
        echo "    (Could not list projects — check that your account has access to '$ORG'.)"
    fi

    echo -e "\nDone. Use Option A (Azure CLI) in reference/usage.md."
    echo "This Skill is scoped to the '$PROJECT' project."
    ;;
  2)
    echo -e "\n==> PAT fallback selected. Skipping Azure CLI."
    echo ""
    echo "In Azure DevOps (https://dev.azure.com/$ORG) create a PAT:"
    echo "  - User settings > Personal access tokens > New Token"
    echo "  - Organization: $ORG"
    echo "  - Scope this token to the '$PROJECT' project ONLY (for a hard boundary)"
    echo "  - Scopes: 'Work Items (Read)'  [add 'Read & Write' only if Claude should update items]"
    echo "  - Set a short expiry and copy the token now (it is shown only once)"
    echo ""
    echo "Then add it to your Claude config as the AZURE_DEVOPS_EXT_PAT env var"
    echo "(see Option B in reference/usage.md)."
    echo ""
    echo "WARNING:"
    echo "  * The token is stored in PLAINTEXT in the config file."
    echo "  * Verify PAT support in the installed server README; the official"
    echo "    server is Entra/Azure-CLI-first and may ignore this env var."
    echo "    If you get 401s, fall back to Option A (Azure CLI)."
    ;;
  *)
    echo -e "\nInvalid choice. Exiting."; exit 1 ;;
esac