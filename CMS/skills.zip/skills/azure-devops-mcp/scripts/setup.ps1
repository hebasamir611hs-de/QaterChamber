# Prerequisite installer for the Azure DevOps MCP server (Windows / PowerShell).
# Organization: ihorizons | Scoped project: Qatar Chamber Website Revamp (Scrum template)
# Auth options: [1] Azure CLI (recommended)  [2] PAT (optional fallback)

$Org     = "ihorizons"
$Project = "Qatar Chamber Website Revamp"

function Update-Path {
    $env:Path = [Environment]::GetEnvironmentVariable("Path","Machine") + ";" +
                [Environment]::GetEnvironmentVariable("Path","User")
}

function Resolve-AzCmd {
    # Bash-invoked shells often can't see 'az'; resolve the full az.cmd path.
    $default = "C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd"
    if (Test-Path $default) { return $default }
    $resolved = Get-Command az -ErrorAction SilentlyContinue
    if ($resolved) { return $resolved.Source }
    $found = Get-ChildItem "C:\Program Files\Microsoft SDKs" -Recurse -Filter az.cmd -ErrorAction SilentlyContinue |
             Select-Object -First 1
    if ($found) { return $found.FullName }
    return $null
}

Write-Host "==> Azure DevOps MCP setup for org '$Org' (project: $Project)"
Write-Host "    NOTE: this project uses the Scrum template -> backlog items are"
Write-Host "          typed 'Product Backlog Item' (NOT 'User Story')."
Write-Host ""

Write-Host "==> Checking Node.js..."
if (Get-Command node -ErrorAction SilentlyContinue) {
    Write-Host "    Found $(node --version)"
} else {
    Write-Host "    Installing Node.js LTS via winget..."
    winget install OpenJS.NodeJS.LTS --silent --accept-package-agreements --accept-source-agreements
    Update-Path
}

Write-Host ""
Write-Host "==> Choose how Claude will authenticate to Azure DevOps:"
Write-Host "  [1] Azure CLI  (recommended; opens a browser, no secret stored)"
Write-Host "  [2] PAT        (optional fallback; token stored in plaintext, can scope to one project)"
$authChoice = Read-Host "Enter 1 or 2"

switch ($authChoice) {
    '1' {
        Write-Host "`n==> Checking Azure CLI..."
        if (Get-Command az -ErrorAction SilentlyContinue) {
            Write-Host "    Azure CLI already installed."
        } else {
            Write-Host "    Installing Azure CLI via winget..."
            winget install Microsoft.AzureCLI --silent --accept-package-agreements --accept-source-agreements
            Update-Path
        }

        $azCmd = Resolve-AzCmd
        if (-not $azCmd) {
            Write-Host "    Could not locate az.cmd automatically. Default path is:"
            Write-Host "      C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd"
            $azCmd = "C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd"
        }

        Write-Host "`n    Using Azure CLI at: $azCmd"
        Write-Host "    NOTE: If a bash shell reports 'az: command not found', run login"
        Write-Host "          from PowerShell using this full path:"
        Write-Host "          & `"$azCmd`" login"

        $doLogin = Read-Host "`nRun 'az login' now (opens a browser)? [y/N]"
        if ($doLogin -match '^[Yy]$') {
            & "$azCmd" login
            Write-Host "`n    Ensuring the Azure DevOps CLI extension is present..."
            & "$azCmd" extension add --name azure-devops 2>$null
            Write-Host "    Verifying org access..."
            & "$azCmd" devops project list --organization "https://dev.azure.com/$Org" --output table
        }

        Write-Host "`nDone. Use Option A (Azure CLI) in reference/usage.md."
        Write-Host "This Skill is scoped to the '$Project' project."
    }
    '2' {
        Write-Host "`n==> PAT fallback selected. Skipping Azure CLI."
        Write-Host ""
        Write-Host "In Azure DevOps (https://dev.azure.com/$Org) create a PAT:"
        Write-Host "  - User settings > Personal access tokens > New Token"
        Write-Host "  - Organization: $Org"
        Write-Host "  - Scope this token to the '$Project' project ONLY (for a hard boundary)"
        Write-Host "  - Scopes: 'Work Items (Read)'  [add 'Read & Write' only if Claude should update items]"
        Write-Host "  - Set a short expiry and copy the token now (shown only once)"
        Write-Host ""
        Write-Host "Then add it to your Claude config as the AZURE_DEVOPS_EXT_PAT env var"
        Write-Host "(see Option B in reference/usage.md)."
        Write-Host ""
        Write-Host "WARNING:"
        Write-Host "  * The token is stored in PLAINTEXT in the config file."
        Write-Host "  * Verify PAT support in the installed server README; the official"
        Write-Host "    server is Entra/Azure-CLI-first and may ignore this env var."
        Write-Host "    If you get 401s, fall back to Option A (Azure CLI)."
    }
    default { Write-Host "`nInvalid choice. Exiting."; exit 1 }
}