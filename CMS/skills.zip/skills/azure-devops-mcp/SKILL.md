---
name: azure-devops-mcp
description: Install, configure, and use Microsoft's official Azure DevOps MCP server for the ihorizons organization, scoped to the "Qatar Chamber Website Revamp" project, so Claude can read and manage backlog items (Product Backlog Items / User Stories, Tasks, Bugs), boards, pull requests, and pipelines. Supports Azure CLI (recommended) and an optional Personal Access Token (PAT) fallback login. Use when the user wants to connect Claude to Azure DevOps or query/update their ADO items.
---

# Azure DevOps MCP Setup & Usage (ihorizons)

Connects Claude to Azure DevOps through Microsoft's official MCP server
(`@azure-devops/mcp`). The recommended and best-supported authentication path is
the **Azure CLI (Entra ID)**, which stores no secret on disk. A **Personal Access
Token (PAT)** is supported as an **optional fallback** — useful when Azure CLI
login isn't possible, or when you want a hard boundary locked to one project.

- **Organization slug:** `ihorizons`
- **Modern URL:** `https://dev.azure.com/ihorizons`
- **Legacy URL (same org):** `https://ihorizons.visualstudio.com`
- **Default / scoped project:** `Qatar Chamber Website Revamp`
  (`https://dev.azure.com/ihorizons/Qatar%20Chamber%20Website%20Revamp`)
- **Project ID:** `8f3dabd4-...` (Scrum process template)
- **Default team:** `Qatar Chamber Website Revamp Team`
  (confirm exact name once; used to answer team-scoped tool prompts automatically)

## Process template — IMPORTANT for work item types
This project uses the **Scrum** process template, so its backlog items are typed
**`Product Backlog Item`** (NOT `User Story`). Agile-template projects use
`User Story`. Always default to `Product Backlog Item` here. Querying `User Story`
will return **zero rows** and can look like an auth/scoping failure when it isn't.

## When to use this Skill
- The user asks to install or configure the Azure DevOps MCP server.
- The user wants to query, summarize, or update backlog items, boards, PRs, or pipelines.
- The user asks why the Azure DevOps tools aren't showing up in Claude.
- Azure CLI login fails and the user needs the PAT fallback.

## Project scoping (IMPORTANT)
This Skill operates **only against `Qatar Chamber Website Revamp` by default.**
- Always include this project name in WIQL queries and tool calls.
- Do **not** query or modify any other project unless the user explicitly names a
  different one and confirms the switch.
- The MCP server itself **cannot enforce project isolation** — the above is a
  *behavioral* guardrail. For a **hard boundary**, use the **PAT fallback with the
  token scoped to this one project**, or an account whose access is limited to it.
  Tell the user this if they ask for true isolation.

## Authentication choices (pick one)
1. **Azure CLI — recommended.** Run `az login` once; the server reuses that
   credential. No secret stored on disk. Inherits the signed-in user's permissions.
2. **PAT — optional fallback.** A token placed in the config env. Use when:
   - Azure CLI can't be installed or the browser login flow is blocked, or
   - you need a genuine per-project security boundary.
   Caveats: the token is stored in **plaintext** in the config, and you must
   **verify PAT support in the installed server's README** — the official server is
   built around Entra/Azure CLI auth, and the PAT env var is not guaranteed to be
   honored by every version. If PAT auth 401s, fall back to Azure CLI.

## Prerequisites (verify first)
1. **Node.js 20+** — check with `node --version`.
2. **Auth method** — Azure CLI (recommended) or PAT (fallback).

Run the prerequisite installer if tools are missing:
- macOS/Linux → `scripts/setup.sh`
- Windows → `scripts/setup.ps1`

Both scripts pre-fill the `ihorizons` org, install Node.js if needed, ask which
auth method to use, and:
- for **Azure CLI**: install the CLI and offer to run `az login` (Windows resolves
  the full `az.cmd` path automatically to avoid the bash `az: command not found`
  problem);
- for **PAT**: print exactly which scopes to select and remind you the token is
  stored in plaintext.

## Windows gotcha (Azure CLI path)
On Windows the Azure CLI installs as `az.cmd` for PowerShell/cmd. If a **bash**
shell runs the command it may report `az: command not found`. That does NOT mean
the install failed — run it from **PowerShell** via the full path:
`& "C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd" login`
(Full details and path-detection in `reference/usage.md` §1.5.)

## Sprint / iteration queries — avoid the team prompt
Iteration ("current sprint") data is **team-scoped**. The team-settings /
iteration lookup tool can **hang, time out, or trigger an interactive
"Select the Azure DevOps team" prompt** that blocks progress.

**Preferred approach:** use the WIQL macro **`@currentIteration`**, which resolves
the active sprint **server-side** without needing a team-settings call or any
prompt. See `reference/usage.md` §5. Only fall back to the iteration tool (and
supply the documented default team) if `@currentIteration` isn't suitable.

## Activation
1. Add the server to Claude Desktop / Claude Code config (full JSON + file paths in `reference/usage.md`).
2. Complete the chosen login (Azure CLI `az login`, or set the PAT env var).
3. Fully quit and relaunch Claude Desktop / restart Claude Code.
4. Confirm the `azure-devops` tools appear in the tools indicator.
5. Run the **verification test** in `reference/usage.md` §3 to read the backlog item list.

## Using the tools
Prefer natural-language requests and let the model pick the tool, but always keep
the project fixed to `Qatar Chamber Website Revamp` and default to the
`Product Backlog Item` type. When enumerating many items, **fetch their details in
a single batched call** rather than one call per item. See `reference/usage.md`
for example prompts, the `QC-` ID prefix glossary, and WIQL patterns.

## Safety notes
- The credential inherits its owner's permissions (signed-in user for Azure CLI,
  or whatever the PAT is scoped to). Azure CLI writes are **real, attributable
  changes** made as the signed-in user.
- Reads are safe; **confirm with the user before any write/update/delete**
  (creating items, changing state, adding comments).
- **Bulk mutations require extra care.** For any write that affects **multiple
  items** (bulk assign, bulk state change, bulk edit/close), FIRST present the full
  list of affected IDs and the exact change, then require **explicit user
  confirmation** before executing. Never bulk-assign or bulk-close without showing
  a preview.
- **Never echo tokens or credentials back into chat.** Treat a PAT like a password.