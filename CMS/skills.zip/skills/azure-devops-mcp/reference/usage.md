# Azure DevOps MCP — Configuration & Usage Reference (ihorizons)

- **Organization slug:** `ihorizons`
- **Modern URL:** `https://dev.azure.com/ihorizons`
- **Legacy URL (same org):** `https://ihorizons.visualstudio.com`
- **Default / scoped project:** `Qatar Chamber Website Revamp`
  (`https://dev.azure.com/ihorizons/Qatar%20Chamber%20Website%20Revamp`)
- **Project ID:** `8f3dabd4-...`
- **Process template:** **Scrum** → backlog items are **`Product Backlog Item`**
- **Default team:** `Qatar Chamber Website Revamp Team` (confirm exact name once)

Both the modern and legacy URLs resolve to the same organization identity; the
MCP server only needs the slug `ihorizons`.

## 0. Work item type cheat-sheet (READ FIRST)
| Process template | Backlog item type | This project? |
|---|---|---|
| **Scrum** | `Product Backlog Item` | ✅ **Yes — use this** |
| Agile | `User Story` | ❌ no |
| CMMI | `Requirement` | ❌ no |

Querying `User Story` here returns **zero rows** even though auth/scoping are
correct. Always default to **`Product Backlog Item`**.

## 1. Add the server to Claude Desktop

Config file location:
- **macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows:** `%APPDATA%\Claude\claude_desktop_config.json`

### Option A — Azure CLI (recommended)
No secret stored; the server reuses your `az login` credential.
```json
{
  "mcpServers": {
    "azure-devops": {
      "command": "npx",
      "args": ["-y", "@azure-devops/mcp", "ihorizons"]
    }
  }
}
```

### Option B — PAT (optional fallback)
Use when Azure CLI login isn't possible, or when you want a hard per-project
boundary. Create the PAT in Azure DevOps with access limited to
**Qatar Chamber Website Revamp** and scope **Work Items (Read)** (add
**Read & Write** only if Claude should update items).
```json
{
  "mcpServers": {
    "azure-devops": {
      "command": "npx",
      "args": ["-y", "@azure-devops/mcp", "ihorizons"],
      "env": {
        "AZURE_DEVOPS_EXT_PAT": "your_pat_here"
      }
    }
  }
}
```
> PAT notes:
> - The token is stored in **plaintext** in this file — protect the file and use a
>   short expiry.
> - The official server is built around Azure CLI / Entra auth, so this PAT env
>   var **may not be read** by every version. If you hit 401s after adding it,
>   fall back to Option A, or use a community server that documents PAT auth
>   explicitly.
> - **Never paste the PAT into chat.** Only place it in the config file.

## 2. Claude Code (instead of Desktop)

Register the server:
```bash
claude mcp add azure-devops -- npx -y @azure-devops/mcp ihorizons
```

Then authenticate with **one** of:
- **Azure CLI (recommended):** run `az login` once (see §1.5 for the Windows
  full-path form), then restart Claude Code.
- **PAT (fallback):** set the env var when registering, for example on
  macOS/Linux:
  ```bash
  claude mcp add azure-devops --env AZURE_DEVOPS_EXT_PAT=your_pat_here -- npx -y @azure-devops/mcp ihorizons
  ```
  On Windows PowerShell:
  ```powershell
  $env:AZURE_DEVOPS_EXT_PAT = "your_pat_here"
  claude mcp add azure-devops -- npx -y "@azure-devops/mcp" ihorizons
  ```

Confirm registration with `claude mcp list`.

## 1.5 Windows note — running `az login` when bash can't find `az`

On Windows, the Azure CLI installs for PowerShell/cmd as `az.cmd`. If Claude Code
(or any tool) runs commands through **bash** (`/usr/bin/bash`), that shell often
won't have `az` on its PATH, and you'll see:

```
/usr/bin/bash: line 1: az: command not found
```

This does **not** mean the install failed. Run it from **PowerShell** using the
full path instead:

```powershell
& "C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd" login
```

Then ensure the ADO extension and verify org access:
```powershell
& "C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd" extension add --name azure-devops
& "C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd" devops project list --organization https://dev.azure.com/ihorizons --output table
```

> Tips:
> - The default install path is
>   `C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd`. If it's elsewhere,
>   find it in PowerShell with:
>   ```powershell
>   Get-Command az | Select-Object -ExpandProperty Source
>   ```
>   or search:
>   `Get-ChildItem "C:\Program Files\Microsoft SDKs" -Recurse -Filter az.cmd -ErrorAction SilentlyContinue`
> - To use plain `az` in the current PowerShell session, refresh PATH:
>   ```powershell
>   $env:Path = [Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [Environment]::GetEnvironmentVariable("Path","User")
>   ```
> - `az login` is **interactive** (opens a browser) — you run it yourself; Claude
>   cannot complete the browser step for you.
> - The MCP server reuses this login automatically once it succeeds — restart
>   Claude Desktop / Claude Code afterward so the `azure-devops` server picks it up.

## 3. Verification test — read the current backlog item list
After activating, run this **as your first test** to confirm auth + scoping work.
This uses the umbrella of backlog types so it works regardless of process template.

**Natural-language prompt:**
> "Using the azure-devops tools, list the current backlog items in the
> **Qatar Chamber Website Revamp** project — show ID, title, state, and assignee.
> Remember this is a Scrum project, so the type is **Product Backlog Item**."

**Expected result:** a table of `Product Backlog Item` rows. If it returns rows,
auth and project scoping are working. If it errors, see §6.

**Process-agnostic verification WIQL** (works for Scrum *and* Agile projects):
```sql
SELECT [System.Id], [System.Title], [System.State], [System.AssignedTo]
FROM workitems
WHERE [System.TeamProject] = 'Qatar Chamber Website Revamp'
  AND [System.WorkItemType] IN ('Product Backlog Item', 'User Story')
  AND [System.State] <> 'Closed'
ORDER BY [System.ChangedDate] DESC
```
> If this returns rows but a `User Story`-only query returned none, that confirms
> the project is **Scrum** — use `Product Backlog Item` going forward.

**Optional pre-launch auth check — confirm login resolves to the right org.**

macOS/Linux (or Windows PowerShell with `az` on PATH):
```bash
az account show
az devops project list --organization https://dev.azure.com/ihorizons --output table
```

Windows PowerShell when `az` isn't on PATH (use the full path to `az.cmd`):
```powershell
& "C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd" account show
& "C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd" devops project list --organization https://dev.azure.com/ihorizons --output table
```
(The `devops` subcommand requires the extension: `az extension add --name azure-devops`,
or via the full path shown in §1.5.)

## 4. Example prompts (all stay within the scoped project)
- "List all active bugs assigned to me in Qatar Chamber Website Revamp."
- "Summarize this sprint's Product Backlog Items and flag any without acceptance criteria."
- "Show work item 129367 and draft improved acceptance criteria for it."
- "Which tasks in the current iteration are blocked or unassigned?"
- "Group the current sprint's PBIs by their QC- area prefix (see §8)."

## 5. Sprint / iteration queries — PREFER `@currentIteration`
Iteration data is **team-scoped**. The team-settings / iteration lookup tool can
**hang, time out, or trigger a 'Select the Azure DevOps team' prompt** that blocks
progress. Avoid all of that by using the **`@currentIteration`** WIQL macro, which
resolves the active sprint **server-side** with no team-settings call and no prompt.

**Current sprint's Product Backlog Items (preferred pattern):**
```sql
SELECT [System.Id], [System.Title], [System.State], [System.AssignedTo]
FROM workitems
WHERE [System.TeamProject] = 'Qatar Chamber Website Revamp'
  AND [System.WorkItemType] = 'Product Backlog Item'
  AND [System.IterationPath] = @currentIteration
ORDER BY [System.Id]
```

> - If a query genuinely needs the iteration/team-settings tool and it prompts for
>   a team, supply the documented default team **`Qatar Chamber Website Revamp Team`**
>   rather than pausing for input.
> - `@currentIteration` can optionally be team-qualified as
>   `@currentIteration('[Project]\Team')` if multiple teams have different sprints.

## 6. Broader WIQL pattern (backlog items, tasks, bugs)
```sql
SELECT [System.Id], [System.Title], [System.WorkItemType], [System.State]
FROM workitems
WHERE [System.TeamProject] = 'Qatar Chamber Website Revamp'
  AND [System.WorkItemType] IN ('Product Backlog Item', 'Task', 'Bug')
  AND [System.State] <> 'Closed'
ORDER BY [System.ChangedDate] DESC
```

### Efficiency tip — batch detail fetching
When enumerating many items, first get the list of IDs (via the WIQL query), then
**fetch their full details in a single batched call** rather than one call per
item. This is faster, avoids rate issues, and is the pattern that worked well in
practice for pulling 20+ PBIs at once.

## 7. Troubleshooting
| Symptom | Fix |
|---|---|
| No Azure DevOps tools appear | Fully quit + relaunch Claude Desktop / restart Claude Code; validate the JSON is well-formed. |
| `az: command not found` in bash | The CLI installed for Windows/PowerShell. Run login from PowerShell via full path: `& "C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd" login` (see §1.5). |
| Verification returns **zero rows** | You probably queried `User Story`. This is a **Scrum** project — query `Product Backlog Item` (see §0). |
| "Select the Azure DevOps team" prompt appears | Team-scoped tool needs a team. Either supply the default team `Qatar Chamber Website Revamp Team`, or better, avoid the tool entirely by using `@currentIteration` in WIQL (§5). |
| Team-settings / iteration lookup hangs or times out | Skip it — use the `@currentIteration` WIQL pattern (§5), which resolves server-side without a team-settings call. |
| 401 / auth errors (Azure CLI) | Re-run `az login`; confirm the account can access `ihorizons` and the project. If it persists, try the PAT fallback (Option B). |
| 401 / auth errors (PAT) | Confirm the server version actually reads `AZURE_DEVOPS_EXT_PAT`; check the PAT isn't expired and includes the right scope/project. If unsupported, fall back to Azure CLI (Option A). |
| Empty sprint result | Confirm items are assigned to the current iteration and aren't all Closed; confirm the project name is exactly `Qatar Chamber Website Revamp`. |
| Can see other projects | Expected with Azure CLI — the server can't isolate projects. Use a **project-scoped PAT** (Option B) or an account limited to that project for a hard boundary. |
| IE Enhanced Security warning in browser | Unrelated to the MCP server; it only affects the ADO web UI in a locked-down browser. Disable IE ESC or use a modern browser. |
| `npx` not found | Node.js missing or not on PATH — run the setup script. |

## 8. Work item ID prefix glossary (Qatar Chamber Website Revamp)
Backlog items follow a `QC-<AREA>-<NNN>` naming scheme that maps to site areas.
Use these prefixes to group, filter, and summarize items intelligently.

| Prefix | Area | Example |
|---|---|---|
| `QC-GBL-###` | Global / site-wide components | `QC-GBL-002 – Language Switcher` |
| `QC-HOME-###` | Home page sections | `QC-HOME-001 – Hero Banner` |
| `QC-GBL-000` | Environment preparation & setup | `QC-GBL-000 – Env's Preparation & Setup` |

> Additional area prefixes may appear as the backlog grows (e.g. news, services,
> members). Treat the segment between the two dashes as the **area code** and the
> trailing number as the sequence within that area. Suffix letters (e.g.
> `QC-HOME-004A`, `QC-HOME-004B`) denote sub-items of the same feature.

## 9. Choosing between Azure CLI and PAT (quick guide)
- **Default to Azure CLI (Option A)** — no stored secret, simplest to maintain.
- **Use the PAT fallback (Option B)** when:
  - the machine can't run `az login` (no browser, locked-down environment), or
  - you need a **true security boundary** limited to `Qatar Chamber Website Revamp`.
- If the PAT env var is ignored by your server version, the practical hard
  boundary is to sign in (via Azure CLI) with an **account that only has access to
  that single project**.

## 10. Write & bulk-write safety (IMPORTANT)
- With **Azure CLI auth**, every write runs as the **signed-in user** and is a
  real, attributable change in Azure DevOps. There is no dry-run.
- **Single writes:** confirm the exact change with the user before executing.
- **Bulk writes** (assigning, state changes, or edits across multiple items):
  1. Query and **present the full list of affected item IDs + titles**.
  2. State the **exact change** to be applied (e.g. "set Assigned To = X on all 22").
  3. **Wait for explicit user confirmation.**
  4. Only then execute — and prefer a batched update call.
- Never bulk-assign, bulk-move, or bulk-close without showing the preview first.